# Programmer: 	Vibhav Mehrotra   
# Company:		Computer Associates Int. Inc.
# Program:		ReserveFiles.pl
# Location:		The perl file (reservefiles.pl) needs to be located under Servers Harvest\bin directory.
# Setup:		This is a pre-link server UDP to a Check in process. 
# Function:		The function of this script is to reserve files before checking them into Harvest. This way the users 
#			don't have to check out files before they check them back into Harvest.
# Usage:		perl.exe reservefiles.pl "[environment]" "[state]" "[package]" "[user]" "[version]"
# Requires:		
#			* Harvest 4.0.2 (This script has only been tested with this version of Harvest).
#			* Check out process with the "Reserve Only" mode.
#			* The user should update the following variables with the required values.
#			* UNIX Servers would require that the check in process have the option "Check In by owner only"
#			  turned OFF.
#			* Harvest bin directory and Oracle Bin directory is in the path so the hco 
#			  and plus33.exe can be run from any location.
#			* Requires Perls Basename module.
#			* NT server requires Decrypt.exe file in the Harvest bin directory.
#			* NT server requires Oracle read only account's username and password.
#

################################################################################################################
#		MODIFY THE FOLLOWING VARIABLES
################################################################################################################

###### Variable telling if your server is UNIX or NT

$servertype = "<Enter your server type here...UNIX or NT>";

###### Process name that has the reserve only mode set.

$pnname = "<Enter the name of your process which has the reserve only mode>";

###### Location where the log files would be written during execution

$servloc = "<Complete location where log files would be written>";

###### For NT servers we require Oracle's read only account name and password

$oracle_user = "harrep";		# Oracle Read Only account
$oracle_password = "harrep";		# Password for that account
						# If the database alias is defined then the password will be "<password\@alias name>"
						# e.g. "harrep\@harv" Where harrep is the password and harv is the alias name.


################################################################################################################


use File::Basename;

# Parsing the variables that were passed by harvest

$env = "$ARGV[0]";		# Environment Name
$state = "$ARGV[1]";		# State Name
$pkg = "$ARGV[2]";		# Package being used to check in files
$user = "$ARGV[3]";		# User executing the process.
@sortedpath = "";

# Setting the slashes based on the server type.

if ($servertype =~ /unix/i) {$slash = "\/";}
else {
	$slash = "\\";
	$pass = getpass($user);
	}

# Assigning log file where the check out information will be stored.
$logfile = "$servloc" . $slash . "$user.log";

# Shifting to the list of files being checked in.
shift;
shift;
shift;
shift;

@sortedpath = mysort(@ARGV);
$olddir = "";
$a = 0;

foreach $version (@sortedpath) {

       $dirpath = dirname($version);
       $filename = basename($version);


       # If the name has a space then we remove it
       if (substr($filename,length($filename)-1) eq " "){
       chop($filename);}

       #Check to see if it is a new directory
       if ($olddir ne $dirpath) {

          # Check if we are doing it for the first time
          if ($olddir eq ""){    #Yes
             $olddir = $dirpath;
 	       $filelist = "\"".$filename."\"";	# Appending the list of files together
	     }

          else {    #No

             exehco();	# Running the hco command to reserve the files.

             # Refresh the file list and the directory name
             $olddir=$dirpath;
	       $filelist = "\"".$filename."\"";
             }

           } #End of if ($olddir ne $dirname)

       else { # Files are in the same location so we will append it to the list of other files.
             $filelist .= " " . "\"". $filename . "\"";
            }

     # Checking out the last files.
      if ($a == $#ARGV){

         exehco();	# Running the hco command to reserve the files.

        }

	$a++;
          
  } # Ending foreach $a (0 .. $#files) loop

# Printing out the check out information
if ($servertype =~ /unix/i) {
	print `cat $logfile`;}
else {
	print `type $logfile`;
}

# Deleting the log file so that next time when we run it we have a clean log information.
unlink("$logfile");


#####################################################################################################################
#	Function to run HCO based on the server type. For UNIX we cannot get the user password so we will have to reserve 
#	the files based the Harvest ID. Where as for UNIX we can use the decrypt utility to get the users password and 
#	reserve the files under their name.

sub exehco {

  if ($servertype =~ /unix/i) {

	system "hco -en \"$env\" -st \"$state\" -vp \"$olddir\" -p \"$pkg\" -pn \"$pnname\" -ro -r -op pc -o \"$logfile\" $filelist";

	}
  else {

	system "hco -usr $user -pw $pass -en \"$env\" -st \"$state\" -vp \"$olddir\" -p \"$pkg\" -pn \"$pnname\" -ro -r -op pc -o \"$logfile\" $filelist";

	}
}

#####################################################################################################################
#	Function that will get the password of the user who is executing the check in process.

sub getpass {

$user_name = '';
$enc_password = '';
$dec_password = '';
$sqlplus = "plus33.exe -s";
$delete_option = 'Y';

my $user_name = $_[0];

# Creating a file with the SQL statement which will get us the encrypted password of the user from the Harvest table.

open(sqlfile,">$servloc\\encpass.sql");

print sqlfile "set pagesize 0;\nset trimspool on;\nset heading off;\n";
print sqlfile "set headsep off;\nset recsep off;\nset verify on;";
print sqlfile "\nset feedback off;\n--set termout off;\n";
print sqlfile "select distinct(encryptpsswd) from haruser\n";
print sqlfile "where username = '$user_name';\nexit;\n";
close (sqlfile);

# Running the SQL statement and assigning the value to the local variable.
$enc_password = `$sqlplus $oracle_user\/$oracle_password \@$servloc\\encpass.sql`;

# Removing and end line characters.
chomp($enc_password);

# Checking to see if any value was returned. If not then the user does not exist in the database.
if (length($enc_password) > 0){
   system "decrypt.exe \"$enc_password\"";}
else {
   print "\n!!!THE SPECIFIED USERNAME \"$user_name\" DOES NOT EXIST!!!\n";
   exit 1;
	}

# Getting the decrypted password from the file.
open (passfile,"encpass.out");
$dec_password = <passfile>;
close (passfile);

# Deleting the files that have were created during execution
if ($delete_option eq 'Y')
{
  unlink ("encpass.out","$servloc\\encpass.sql");
}

######### Returning the password
return $dec_password;


}

#####################################################################################################################
#	Function that will sort the list of paths based on the directory structure and not in alphabetical order.

sub mysort {

	my @aftersort = @_;
	my @leftdir = "";
	my @rightdir = "";
	my $tempstore = "";
	my $i = 0;		# Inner loop variable
# Sorting the dir list first based on alphabetical list.
sort @aftersort;

	foreach $p (0 .. $#aftersort) {
	# Going through the loop and sorting it based on the number of directories.
	foreach $i (0 .. $#aftersort) {


			if ($servertype =~ /unix/i) {

				@leftdir = split /\// , $aftersort[$i];
				@rightdir = split /\//, $aftersort[$i+1]; }
			else {
				@leftdir = split /\\/ , $aftersort[$i];
				@rightdir = split /\\/, $aftersort[$i+1]; 

			}

			# Check which one has more directories. 
			if (($#leftdir > $#rightdir) && ($#rightdir != -1)) {

				# Switch them around
				$tempstore = $aftersort[$i];
				$aftersort[$i] = $aftersort[$i+1];
				$aftersort[$i+1] = $tempstore;
			}


	} # End of For Loop
}
return @aftersort;
}