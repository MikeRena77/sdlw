To install, place Hv_env.pm and hv_rename_item.pl in the same
directory.  Hv_env.pm should not be readable by anyone except the
Harvest Administrator userid.  The UDP should be created as a
server-side UDP only.  hv_rename_item can be viewable by others, but
there is no need for it to be.

Hv_rename_item.pl should not need any modification, although for an NT
server, you might need to hardcode the Oracle instance by setting
$ENV{ORACLE_SID} to the instance name.  

Hv_env.pm needs to be modified so that prodDB is replaced the Oracle
instance name for your production Harvest's Oracle DB, and the
username and password (ADMIN, ADMINPW) should be set to the username
and password used by the Harvest servers to log into the Oracle
database.