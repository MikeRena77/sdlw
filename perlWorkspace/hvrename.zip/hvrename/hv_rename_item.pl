#!/usr/local/perl5/bin/perl -w
#
# @(#)/ta_workbench/hv_rename_item;0: Production Tech Arch 04/20/2001;17:11:09 Bruce Albrecht
#
#
# FINGERHUT Corporation
# Proprietary Source
#
# TEAM:     Technical Architecture
# FILE:     hv_rename_item
# AUTHOR:   Bruce Albrecht
# CREATED:  11/05/99
# REMARKS:  Rename item in Harvest
#
#
# HISTORY:
# who               when            what
# -----------       --------        ---------------------
# Bruce Albrecht    11/05/99        Initial

use strict;
use DBI qw(:sql_types);
use FindBin;
use lib ($FindBin::RealBin);
use Hv_env;

die "$0: <environment> <state> <Case insensitive> <same except case> <same path> <item> ... <item>  <new name>\n"
  unless @ARGV>=7;

my ($environment, $state) = splice (@ARGV,0,2);
my ($case,       # new item cannot be same case-insensitive name as an existing item in viewpath
	$same,       # new item name must be case-insensitive equivalent to original item name
	$samepath,   # new item viewpath must be same as old viewpath
   ) = map {/^\d+$/ ? $_ : /^y/i || 0 } splice(@ARGV,0,3);

$ENV{ORACLE_SID} = $ENV{TWO_TASK} if $ENV{TWO_TASK};

my ($newpath, $newpathobjid, $hostpath, $sthost, $stpath, $fullitem,
	$fullversion, %items, $strep, $stitem, $stmove, $repositobjid, $stversion,
	$oldpath, $olditem, $newitem, $stcase, $check, $envobjid, $stateobjid,
	$path, $pathobjid, $objid, $item, $Dnew, $Dold, $Vnew, $Vold);

my $dbh = DBI->connect("dbi:Oracle:$ENV{ORACLE_SID}",
					   $Hv_env::Update{$ENV{ORACLE_SID}}{user},
					   $Hv_env::Update{$ENV{ORACLE_SID}}{password},
					   { AutoCommit => 0 }) or
  die "$0: Unable to connect to database: $DBI::errstr\n";

END { $dbh->disconnect if $dbh };

if ($environment !~ /any/i)
{
  my $sth = $dbh->prepare("select envobjid from harenvironment " .
						  " where environmentname = " .
						  $dbh->quote($environment)) or
							die "Can't look up environment";
  $sth->execute;
  ($envobjid) = $sth->fetchrow_array;
  die "Unknown environment" unless $envobjid;

  if ($state !~ /any/i)
  {
	$sth = $dbh->prepare("select stateobjid from harstate " .
						 "where envobjid = $envobjid " .
						 "and statename = " . $dbh->quote($state)) or
						   die "Can't look up state";
	$sth->execute;
	($stateobjid) = $sth->fetchrow_array;
	die "Unknown state" unless $envobjid;
  }
}

$stpath = $dbh->prepare("select pathobjid from harpathfullname where pathfullname = ?")
  or die "$0: Unable to location path: $dbh->errstr\n";

($oldpath, $olditem) = $ARGV[0] =~ m-^/?(.*?)([^/]+?)(;[\d.]+)?$-;

my $new = pop @ARGV;
my $new_is_dir = 0;
$new = "/" . $oldpath . $new unless ($new =~ m-/-); # if just name
$new =~ s-//+-/-g; # remove extraneous "/"
$new =~ s-/$--;   # remove trailing "/"
$stpath->execute(substr($new,1)."/");  # look up path
if (($newpathobjid) = $stpath->fetchrow_array)
{
  die "$0: $new cannot be a viewpath\n" if $samepath || $same;
  $newpath = substr($new,1);
  $newitem = "";
  $new_is_dir = 1;
}
else
{
  die "$0: $new must be a viewpath if more than one item is selected\n" if @ARGV > 1;
  ($newpath, $newitem) = $new =~ m-^/?(.*?)([^/]+?)(;[\d.]+)?$-;
  $stpath->execute($newpath);
  $newpathobjid = $stpath->fetchrow_array;
}

die "$0: $new must be an existing viewpath.\n" if @ARGV > 1 && ! $new_is_dir;

die "$0: Couldn't find viewpath $new\n" unless $newpathobjid;

die "$0: Error in path $ARGV[0]\n" unless $oldpath ne "" && $olditem ne "" && $newitem ne "";

die "$0: /$newpath$newitem must be in the same directory as $ARGV[0]\n"
  if $samepath && $oldpath ne $newpath;

die "$0: /$newpath$newitem must be the same as $ARGV[0] except for case\n"
  if $same && "\U$oldpath$olditem" ne "\U$newpath$newitem";

exit 0 if "$oldpath$olditem" eq "$newpath$newitem";

$sthost = $dbh->prepare("select hostpath from harrepository where repositobjid = ?")
  or die "$0: Unable to locate repository path: $dbh->errstr\n";

$strep = $dbh->prepare("select repositobjid from haritempath where pathobjid = ?")
  or die "$0: Unable to locate repository: $dbh->errstr\n";

$stitem = $dbh->prepare("select itemobjid from haritem where pathobjid = ? and itemname = ?")
  or die "$0: Unable to locate item $dbh->errstr\n";

$stcase = $dbh->prepare("select itemname from haritem where pathobjid = ? and UPPER(itemname) = ?")
  or die "$0: Unable to locate item $dbh->errstr\n";

$stmove = $dbh->prepare("update haritem set pathobjid = ?, itemname = ? where itemobjid = ?")
  or die "$0: Unable to move item $dbh->errstr\n";

$stversion = $dbh->prepare("
select mappedversion, v.packageobjid, environmentname, statename
from harversion v, harpackage p, harenvironment e, harstate s
where itemobjid = ?
and v.packageobjid = p.packageobjid(+)
and p.stateobjid = s.stateobjid
and p.envobjid = e.envobjid " .
($envobjid ? "and (p.envobjid != $envobjid " : "") .
($stateobjid ? "or p.stateobjid != $stateobjid) " : ")")) or
  die "$0: Unable to check versions $dbh->errstr\n";

$strep->execute($newpathobjid);
unless (($repositobjid) = $strep->fetchrow_array)
{
  die "$0: Unable to locate repository: /$newpath\n";
}
$sthost->execute($repositobjid);
unless (($hostpath) = $sthost->fetchrow_array)
{
  die "$0: Unable to locate path: /$newpath\n";
}

item:
foreach $fullitem (@ARGV)
{
  my ($path, $name) = ($fullitem =~ m-^/?(.*?)([^/]+?)(;[\d.]+)?$-);
  $stpath->execute($path);
  unless (($pathobjid)=$stpath->fetchrow_array)
  {
	warn "$fullitem not found.\n";
	next item;
  }
  $strep->execute($pathobjid);
  unless (($objid) = $strep->fetchrow_array)
  {
	warn "$fullitem not found.\n";
	next item;
  }
  if ($objid != $repositobjid)
  {
	warn "$fullitem is not in the same repository as /$newpath and will not be moved.\n";
	next item;
  }
  $stitem->bind_param(1, $pathobjid, SQL_NUMERIC);
  $stitem->bind_param(2, $name, SQL_CHAR);
  $stitem->execute;
  unless (($item) = $stitem->fetchrow_array)
  {
	warn "$fullitem not found.\n";
	next;
 }
  if ($envobjid)
  {
	$stversion->execute($item);
	my $found = 0;
	my $base = 0;
	while (my($mv, $pkg, $env, $st) = $stversion->fetchrow_array)
	{
	  if ($pkg)
	  {
		$mv =~ s/\s+$//;
		$env =~ s/\s+$//;
		$st =~ s/\s+$//;
		warn "Unable to move $fullitem because version $mv is in environment $env, state $st\n";
		$found = 1;
	  }
	  else
	  {
		$base++;
	  }
	}
	next item if $found;
	if ($base > 1)
	{
	  warn "Unable to move $fullitem because it exists in more than one environment\n";
	  next item;
	}
  }
  $newitem = $name if $new_is_dir;
  $stitem->bind_param(1, $newpathobjid, SQL_NUMERIC);
  $stitem->bind_param(2, $newitem, SQL_CHAR);
  $stitem->execute;
  if (($objid) = $stitem->fetchrow_array)
  {
	warn "/$newpath$name already exists, $fullitem will not be moved.\n";
	next item;
  }

  if ($case && ($pathobjid != $newpathobjid || "\U$name" ne "\U$newitem"))
  {
	$stcase->execute($newpathobjid, "\U$newitem");
	while (($check) = $stcase->fetchrow_array)
	{
	  warn "/$newpath$check exists, $fullitem will not be moved.\n";
	  next item;
	}
  }

  $stmove->bind_param(1, $newpathobjid, SQL_NUMERIC);
  $stmove->bind_param(2, $newitem, SQL_CHAR);
  $stmove->bind_param(3, $item, SQL_NUMERIC);
  if ($stmove->execute != 1)
  {
	warn "Move failed for $fullitem.\n";
	next item;
  }

  # move D and V components
  $Dold = "$hostpath/D/$path$name";
  $Dnew = "$hostpath/D/$newpath$newitem";
  $Vold = "$hostpath/V/$path$name";
  $Vnew = "$hostpath/V/$newpath$newitem";
  unless ( rename("$Dold", "$Dnew"))
  {
	warn "Unable to move repository components for $fullitem.\n";
	if ($stmove->execute($pathobjid, $name, $item) != 1)
	{
	  warn "Unable to restore $fullitem in database\n";
	}
	next item;
  }
  unless ( rename("$Vold", "$Vnew"))
  {
	warn "Unable to move repository components for $fullitem, $fullitem will not be moved.\n";
	if ($stmove->execute($pathobjid, $name, $item) != 1)
	{
	  warn "Unable to restore $fullitem in database\n";
	}
	next item;
	warn "Unable to restore D component for $fullitem\n" unless rename($Dnew, $Dold);
  }
}

$stpath->finish;
$sthost->finish;
$strep->finish;
$stitem->finish;
$stmove->finish;
$stcase->finish;

$dbh->disconnect;

__END__

=head1 NAME

hv_rename_item - rename items in Harvest

=head1 SYNOPSIS

B<hv_rename_item> I<environment> I<state> I<case> I<samename> I<samepath> I<path> ... I<path>

=head1 DESCRIPTION

This script renames items in Harvest.  If the parameters allow it, and
the last parameter is a view path, then the items are moved to the
view path, as long as it does not move them items from one repository
to another.

The script should be called as a server-side UDP with the following parameters:

  hv_rename_item [environment] [state] <case> <samename> <samepath> [version]

and the new name or path should be entered as an additional command
parameter.  The user should select one or more versions or items
before selecting the UDP from the Process menu.  If more than one
version/item is selected, then the last parameter must be a view path.

If only one version/item is selected, and the additional command
parameter does not contain any slashes ("/"), the script assumes the
user meant to rename the item to the new name in the same viewpath.

The first five parameters are:

=over

=item I<environment>

This parameter limits all versions to be in the same environment.
Because moving the item to a new directory, or changing its name
affects all versions, in all environments, this parameter limits the
rename to only items that are created in this environment through
check-in.  Use ANY to allow users to rename any item, even if it has
versions in more than one environment.

=item I<state>

This parameter limits all versions to be in the same state.  Use ANY
to allow users to rename any item, even if it has versions in more
than one state. If there are any automated processes in the lifecycle
to create reference directories upon package promotion, this should
not be set to ANY because it could leave extra files in the reference
directories.

=item I<case>

Pass 1 or Y if the item is allowed to be renamed even if another item
with the same case-insensitive name exists.  For example, if the
clients are Unix based, the files "Happy.html" and "happy.html" are
two different files, but reference the same file on a Windows client.
Therefore, if the users are working with files destined for a unix system,
this parameter could be 1, but for Windows environments, it should be 0 or N.

=item I<samename>

Pass 1 or Y if the item can only be renamed to some case-insensitive
variation of the name.  For example, "Happy.html" can be renamed
"HAPPY.HTML" or "happy.html" but not "happy.htm".

=item I<samepath>

Pass 1 or Y if the item(s) can only be renamed to some new name in the
same viewpath.

=back

=cut

