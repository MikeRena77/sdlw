#!/usr/local/bin/perl -w
#
# @(#)/ta_workbench/Hv_env.pm;0: Production Tech Arch 04/13/1999;12:16:07 Bruce Albrecht
#
#
# FINGERHUT Corporation
# Proprietary Source
#
# TEAM:     Technical Architecture
# FILE:     Hv_env.pm
# AUTHOR:   Bruce Albrecht
# CREATED:  09/13/96
#
#
# HISTORY:
# who               when            what
# -----------       --------        --------------------------------------
# Bruce Albrecht    06/12/97        
#
#

package Hv_env;

%Hv_env::Update = ("prodDB" => {"user" => "ADMIN", "password" => "ADMINPW"},
					 "devDB" => {"user" => "ADMIN", "password" => "ADMINPW"},
					);
%Hv_env::Select = ("pta001" => {"user" => "harrep", "password" => "harvest"},
					 "dvta01" => {"user" => "harrep", "password" => "harvest"},
					);

1;
