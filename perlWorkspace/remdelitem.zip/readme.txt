Readme.txt
-----------------------------------------------------------------------------
 Michael Heirler, Siemens ElectroCom GmbH - PL PA TE SE
 Please send comments, hints.. to 
      Michael.Heirler@kst.siemens.de
-----------------------------------------------------------------------------

 Short Documentation
 -----------------------------------------------------------------------------
 - This script removes D-Tagged items in a reference directory: 
   It could be uses as standalone Skript or can be added as UDP to a PRE or POST link
   of a Harvest Process.
   I tried to write the skript as readable as possible avoiding complex constructions
   or tricks. 
   The skript isn't a greyhound, but it do the job we need
   There will be an optimized version in the future. 
   Planned optimizations
       Sort the directories and change only once to a directory (if needed)
 ----------------------------------------------------------------------------
   - First it looks if in the reference a Signature file exits and look wether the
     information in the Signature match with the parameters. (Environment & State )
   - Launch a hsql query to get all D-tagged files in this env , state and write the
     result into a log file
   - Process the log file and delete all found items out of the reference
   - Update the Signature
  
==============================================
   Requirements: 
	A perl installation
	Tested with CCC/HARVEST 4.0.2
all parameters  
     user & password  on NT  UNIX user should be user in Harvest
==============================================
 call:
perl rem_del_item.pl <options>
         -h   print help and exit
         -d   the Reference directory directory
         -e   the environment the files should come from
         -s   the state the files should come from
         -u   a valid user
         -p   the password
         -l   a log-file (the deleted files)
         -v   the view path
 --------------------------------------------------------------------------------

 Example:
NT:
  perl rem_del_item.pl -e SEC-Sample -s Development -v /sample_mh -d c:\work\test -u user -p password -c

UNIX:
 perl rem_del_item.pl -e SEC-Sample -s Development -v /sample_mh -d /usr/local/ref -c


-------------------------------------------------------------------------------------------------------------
