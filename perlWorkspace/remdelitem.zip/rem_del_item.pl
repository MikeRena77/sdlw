#----------------------------------------------------------------------------
#@(#) Last Changed by harvest in SEC-Sample  state: Development  rem_del_item.pl)
#@(#) Unique HARVEST_ID: 59137
#@(#) Date:    Created: 09/15/1999;14:10:33
#@(#) Checkout performed by user harvest at 09/15/1999;14:11:13; size:  11618 Bytes
#
#-----------------------------------------------------------------------------
# Michael Heirler, PL PA TE SE
# Please send comments, hints.. to 
#      Michael.Heirler@kst.siemens.de
#-----------------------------------------------------------------------------
#
# Short Documentation
# -----------------------------------------------------------------------------
# - This script removes D-Tagged items in a reference directory: 
#   It could be uses as standalone Skript or can be added as UDP to a PRE or POST link
#   of a Harvest Process.
#   I tried to write the skript as readable as possible avoiding complex constructions
#   or tricks. 
#   The skript isn't a greyhound, but it do the job we need
#   There will be an optimized version in the future. 
#   Planned optimizations
#       Sort the directories and change only once to a directory (if needed)
# ----------------------------------------------------------------------------
#   - First look if in the reference a Signature file exits and look wether the
#     information in the Signature match with the parameters. (Environment & State )
#   - Launch a hsql query to get all D-tagged files in this env , state and write the
#     result into a log file
#   - Process the log file and delete all found items out of the reference
#   - Update the Signature
#  
#==============================================
#   Requirements: all parameters  
#     user & password  on NT  UNIX user should be user in Harvest
#==============================================
# call:
# rem_del_item.pl <options>
#         -h   print help and exit
#         -d   the Reference directory directory
#         -e   the environment the files should come from
#         -s   the state the files should come from
#         -u   a valid user
#         -p   the password
#         -l   a log-file (the deleted files)
#         -v   the view path
# --------------------------------------------------------------------------------
#
# Example:
#NT:
#  perl rem_del_item.pl -e SEC-Sample -s Development -v /sample_mh -d c:\work\test -u user -p password -c
#
#UNIX:
# perl rem_del_item.pl -e SEC-Sample -s Development -v /sample_mh -d /usr/local/ref -c
#
##############################################################################
# Status:	NT	Test ok	 	       
#         		UNIX	Test ok
#     Tested:
# 			Non existing directories in Ref because all files are deleted  (8.6.99)
#			-d ./xy (8.6.99)				
#-----------------------------------------------------------------------------

use Cwd;       # cwd()
    #
    #     Global variables and initialization
    #     -------------------------------------------------
my @pack;
$this_file	= "rem_del_item.pl";    # @(#)

$hsql	= "delitem.sql";		# intermediate file
$hlog	= "hsqlout.log";		# intermediate file
$log	= "delitem.log";		# the logfile with the deleted items (the default)
$hstmp	= "hsign.tmp";		# A temp file

$nr_rem = 0;			# The number of removed files 
     
$vpath	= "*";    			# view path of repository
$rdir	= "*";			# the root of the reference directory
$env	= "*";			# the environment
$state	= "*";			# the state
$usr	= "*";			# the user
$pass	= "*";			# the password

      #
      #  platform specific Section
      #

$hk	= "\047";	#  -> '
$hk1	= "\042";	#  -> "   
$stern	= "\052";	#  -> *
$sl_nt	= "\134";	#  -> \    NT
$sl_uni	= "\057";	#  -> /    UNIX
$hsig	= "hsig";	# Signature file : NT    

$op_sys  = GetOS();
if ($op_sys eq "UNIX"){
  $hsig	   = ".hsig";	# Signature file: Unix
  $usr	   = "";		# UNIX doesn't need a User
  $pass    = "";		# UNIX doesn't need the passw
}
    #
    #    check the arguments
    #
$i=0;
while ($i <= $#ARGV){
    if  ($ARGV[$i] EQ "-h"  ||  $ARGV[$i] EQ "-H"){ Help(); }
      elsif  ($ARGV[$i] eq "-e")	{ $i++;   $env	= $ARGV[$i]; }
      elsif  ($ARGV[$i] eq "-s")	{ $i++;   $state	= $ARGV[$i]; }
      elsif  ($ARGV[$i] eq "-v")	{ 	
				  $i++;     
				  $vpath    = $ARGV[$i]; 
 				}
      elsif  ($ARGV[$i] eq "-d")	{ $i++;   $rdir     = $ARGV[$i]; }
      elsif  ($ARGV[$i] eq "-l")	{ $i++;   $log	= $ARGV[$i]; }
      elsif  ($ARGV[$i] eq "-u")	{ $i++;   $usr	= $ARGV[$i]; }
      elsif  ($ARGV[$i] eq "-p")	{ $i++;   $pass	= $ARGV[$i]; }
      else{
     	print ("Error in Command Line\n");
     	print (" Unknown Option $ARGV[$i]\n");
     	Help();
    }
    $i++;
}
    #
    # Got All Parameters?
    # ----------------------------------
if ($vpath  eq "*")	{  print ("Argument -v (viewpath) missing\n");		Help(); }
if ($rdir     eq "*")	{  print ("Argument -r (reference directory) missing\n");	Help(); }
if ($env     eq "*")	{  print ("Argument -e (environment) missing\n");	Help(); }
if ($state  eq "*")		{  print ("Argument -s (state) missing\n");		Help(); }
if  ($usr    eq "*" || 
   $pass eq "*")     { print ("Argument -u -p User / Passwordmissing\n");	Help(); }

    # 
    #-- Open the log_file
    #
($sec, $min, $hour, $mday, $mon, $year) = localtime(time);
     
open (LOG, ">$log") or die ("Unable to open the log-file: $log\n");
print LOG "The following items are deleted from the reference directory:\n";
print LOG "$rdir   ($mday.$mon.$year  $hour:$min:$sec)\n";
print LOG " -----------------------------\n";
    #
    # Search a Signature in the reference directory
    #
$act_dir = cwd();
chdir "$rdir" || die "Can't Change to $rdir\n";
if (-e $hsig){
    #
    #   Identify the Reference directory - Get Environment State and the viewpath
    #

  $cmd_string = "hsigget -t -o $hstmp -a environment state viewpath";
  system ("$cmd_string") == 0 || die "Error: system call hsigget -\n";
    #
    #  Extract Environment State Viewpath
    #  Example:
    #
    # TEST.DAT	SEC-Sample      Development     /sample_mh
    # ring1.txt	SEC-Sample      Development     /sample_mh
    #
  open (TTT, "$hstmp") || die ("Can't open log of hsigget: $hstmp\n");
  $str = <TTT>;
  @tmp = split(/\t/, $str);
  close (TTT);
  unlink "$hstmp";       # Delete the log
}
else{
  print "reference is empty or root of ref contains no signature file\n";
  print "Search for hsig: Not Yet implemented\n";
  exit(); 
}  
    #
    # Compare Signature informations with the Signature
    # -- Environment
if ($env ne $tmp[1]){ 
  print "Environment mismatch: specified: $env -- Signature: $tmp[1]\n";
}
    #-- State
if ($state ne $tmp[2]){
  print "State mismatch: specified: $state -- Signature: $tmp[2]\n";
}
   #-- View path
$vpath =~ s:\\:\/:g;	# Normalize to internal UNIX path
$vpath =~ s:\/$::;	# Normalize the vpath without a trailing /
$vpath =~ s:^\/::;	# Normalize the vpath witkout a leading /
$tmp[3] =~ s:^\/::;	# tmp dito
if ($vpath ne $tmp[3]){
  print "Internal and external paths are not equal\n\n";
  print "try to combine view paths will be implemented in a later version\n";
  exit();
}
    #  Create the sql to extract all Deleted Items in the specified
    #  Environment/State
    #
open (HSQ, ">$hsql") or die ("Unable to create SQL statement file:\n");
print HSQ  "SELECT DISTINCT\n";
print HSQ  "itemname,  pathfullname, versionstatus\n";
print HSQ  "FROM\n";
print HSQ  "harItem, harVersion, harEnvironment, harState, harItemPath, harPathFullName\n";
print HSQ  "WHERE\n";
print HSQ  "HarItem.itemobjid = harVersion.itemobjid  AND\n";
print HSQ  "harVersion.versionstatus = 'D'  AND\n";
print HSQ  "harEnvironment.environmentname = $hk$env$hk AND\n";
print HSQ  "harEnvironment.envobjid = harVersion.envobjid AND\n";
print HSQ  "harState.statename = $hk$state$hk AND\n";
print HSQ  "harState.stateobjid = harVersion.stateobjid AND\n";
print HSQ  "harItem.pathobjid = haritemPath.pathobjid AND\n";
print HSQ  "harPathFullName.pathobjid = harItem.pathobjid\n\n";
close (HSQ);
    #
    # Call the SQL and write the result to $hlog
    #
if ($op_sys eq "UNIX"){
    $cmd_str = "hsql -t -f $hsql -o $hlog";
}
elsif ($op_sys eq "NT"){
    $cmd_str = "hsql -usr $usr -pw $pass -t -f $hsql -o $hlog";
}
system ("$cmd_str") == 0 or die "Error: system call hsql:\n";
    #
    # Process $hlog
    #
open (INN, "$hlog") || die ("Unable to open input file: $hlog");
while (<INN>){
  next if (/^ITEMNAME/);			# Skip all lines beginning with ITEMNAME
  next if (/^-+/);				# Skip all lines beginning with '-----------
  @tmp      = split (/\t/);			# Split the result line
  $position = index ($tmp[1], $vpath);	# Search the viewpath ? is $vpath part of tmp[1] 
  if ($position == -1){
    #
    #   No It is'nt. Automatic search : Not Yet Implemented
    #
  } 
  if ($position == 0){ 	            			#
    $act_path = cwd();				   	# save actual directory
    $new_path = substr ( $tmp[1], length ($vpath) );	# Create working path
      #
      # remove trailing slash
      #
    if ($op_sys eq "NT"){
     $new_path =~ s:^\\::;			#  Remove leading \
     $rdir =~ s:\\$::;         			#  Trailing \
  }
    elsif ($op_sys eq "UNIX"){		# dito
     $new_path =~ s:^\/::;			# 	
     $rdir =~ s:\/$::;			#
  }
    $new_path = $rdir . "/" .$new_path;	#  Reference + viewpath
    $new_path =~ s:\/\/:\/:g;		#  No double slash
    if ($op_sys eq "NT")     { $new_path =~ s:\/:\\:g; }
    if ($op_sys eq "UNIX")  { $new_path =~ s:\\:\/:g; }
    $status =chdir "$new_path";
    if ($status == 0){
      print LOG "Unable to change to $new_path -- Dir doesn't exist in the actual Reference\n";
    }
    else{
      #
      # remove the item from the reference
      # unlink return the numer of files removed 
      #
      $cnt = unlink "$tmp[0]";       
      if ($cnt > 0){ 
        $nr_rem += $cnt;
        print LOG "$new_path  $tmp[0]\n";
          #
          #  Update the Signature file
          #
        system ("hsigget -purge -o $hstmp") == 0 || die "Error: system call hsigget -purge\n";
        unlink "$hstmp";
      }
      chdir "$act_path" || die "Can not change to $act_path\n";
    }
  }
}
close (INN);
     #
     # terminate and close the log file
     #
print LOG " -----------------------------\n";
print LOG " Files Removed: $nr_rem\n";
print LOG " ------------   end ----------\n";

close (LOG);

unlink ($hsql);     
unlink ($hout);
unlink ($hlog);
exit();
      ################################################
      #
      # Sub help
      #
      ###################################################
sub Help
{
    print (   "\$this_file [-options]\n");
    print (   "\toptions:\n\n");
    print (   "\t-h\t\tprint this help\n");
    print (   "\t-d\t\tThe Reference directory\n");
    print (   "\t-e\t\tenvironment\n");
    print (   "\t-l\t\tThe Logfile\n");
    print (   "\t-p\t\tThe user's password\n");
    print (   "\t-s\t\tstate\n");
    print (   "\t-u\t\tA user in harvest\n");
    print (   "\t-v\t\tView path\n");
    exit (1);
}

      ###################################################
      #
      # Sub GetOS
      #
      # On what system is this script running? (Unix OR NT)
      #
      ###################################################
sub GetOS
{
    return ("NT")     if (system ("ver") == 0);
    return ("UNIX") if (system ("uname") == 0);
    return ("undefined");
}
