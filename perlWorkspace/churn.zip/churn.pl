eval 'exec perl  `which ${0%}` "$@"'	# -*- Perl -*-
   if 0;

#!/bin/env perl  

###########################################################################
# File:  vstats.pl
#
# March 98 [mpg]
#
# Description: This perl script is used to calculate the lines changed/
#              added/deleted statistics for VTune files. It takes in two
#              snapshots and determines the number of files added/deleted/
#              changed, checks out the appropriate versions of the changed
#              files, uses diff to report the statistics, and outputs the
#              results in a tab-delimited text file.
#              Versions for the files:
#                       File        Version 1    Version 2
#                       added          -1        snapshot2
#                      deleted      snapshot1        -1
#                      changed      snapshot1    snapshot2
#
# Parsing Diff: This is how diff is parsed to give the statistics
#               lines in file 1 -> lines in file 2
#               Adds: 12a13,14
#                     Since this is a straight add, we are only interested in
#                     the lines added to file 2 (lines 13,14)
#            Deletes: 12,14d12
#                     Straight delete. Interested in lines deleted from file 1.
#            Changes: 12,14c12,15
#                     If the range of lines in file2 > range lines file1, lines 
#                     were added.
#                     If range lines file2 < range lines file1, lines deleted.
#                     Else, straight change.
#
# Usage: perl vstats.pl [flags]
#        -h       help
#        -1 FILE  input file, first snapshot
#        -2 FILE  input file, second snapshot
#        -s       source files only (.c,.h,.frm,.bas,.cpp,.hpp,.rc)
#        -o FILE  writes the summary for the change log to a logfile
#
# Written by:  Emmy Huang
#              Rotation Engineer
#              MPL Support
#
#              Email: emmy_c_huang@ccm.intel.com
#
# Last modified: March 26, 1998
#
# Copyright (C) 1998, Intel Corporation.
#
###########################################################################

###########################################################################
# Helper Functions
# Diff parser
###########################################################################
#-------------------------------------------------------------------------
# count_deltas
# Uses the temporary file created by calling diff on two files. Parses
# the file and counts the numbers of add, change, and deletes
#-------------------------------------------------------------------------
$hco_cmd="hco -v -en \"VTune 3.0 Model\" -st Development -usr x -pw x -br -r -op as -pn \"Check Out for Browse (Read-only)\" ";

sub count_deltas
{
    local($line);    
    local(@data,@linesF1,@linesF2,$range,$range2,$F1,$F2);

    open(TMP,"tmp.diff") or die "Error (count_deltas): can't open tmp.diff for reading!\n";
    while(<TMP>){
	chop;
	$line = $_;
	if($line =~ /\A\d*[,|a|c|d]/){
	    if($line =~ /a/){
		# ADDED LINE
		#------------ diff output L1aL2,L3
		@data = split 'a',$line;
		@linesF2 = split ',',$data[1];
		$range = scalar @linesF2;
		if($range == 1){
		    $lines_added++;
		}
		else{
		    $lines_added += $linesF2[1] - $linesF2[0] + 1;
		}
	    }
	    elsif($line =~ /d/){
		# DELETED LINE
		#------------ diff output L1,L2dL3
		@data = split 'd',$line;
		@linesF1 = split ',',$data[0];
		$range = scalar @linesF1;
		if($range == 1){
		    $lines_deleted++;
		}
		else{
		    $lines_deleted += $linesF1[1] - $linesF1[0] + 1;
		}
	    }
	    elsif($line =~ /c/){
		# CHANGED LINE
		#------------ diff output L1,L2dL3,L4
		@data = split 'c',$line;
		@linesF1 = split ',',$data[0];
		@linesF2 = split ',',$data[1];
		$range = scalar @linesF1;
		$range2 = scalar @linesF2;
		if($range == 2){
		    $F1 = $linesF1[1] - $linesF1[0] + 1;
		}
		else{
		    $F1 = 1;
		}
		if($range2 == 2){
		    $F2 = $linesF2[1] - $linesF2[0] + 1;
		}
		else{
		    $F2 = 1;
		}
		# now figure out how many lines were changed, added, deleted
		$line_diff = $F2 - $F1;
		if($line_diff < 0){
		    $lines_changed += $F2;
		    $lines_deleted += 0 - $line_diff;
		}
		elsif($line_diff > 0){
		    $lines_changed += $F1;
		    $lines_added += $line_diff;
		}
		else{
		    $lines_changed += $F1;
		}
	    }
	    else{
		print "not reached\n";
	    }
	}
    }
    close TMP;
}
#---------------------------------------------------------------------------
# parse_diff
# Takes two files as input and creates the tmp.diff file that contains the
# diff output.
# Uses count_deltas to rollup the statistics
# Returns the number of lines added/deleted/changed
#---------------------------------------------------------------------------
sub parse_diff
{
    local($file1, $file2,$lines_add,$lines_del,$lines_unch);
 
    $file1 = $_[0];
    $file2 = $_[1];
    #print STDERR "file1: $file1 file2: $file2\n"; #DEBUG
    $lines_added = 0;
    $lines_deleted = 0;
    $lines_changed = 0;
    `diff -b $file1 $file2 > tmp.diff`;
    &count_deltas;
#    `rm -f tmp.diff`;
    return "$lines_added/$lines_deleted/$lines_changed";
}



##########################################################################
# Subroutines
##########################################################################
%changed_files;
#-------------------------------------------------------------------------
# add_file
# File added to snapshot, adds it to the changed_files hash
# versions = -1, current
#-------------------------------------------------------------------------
sub add_file
{
    # add L1aL2L3. Only care about lines added in file 2
    local($i,$num_files,$line,@data,$range,@filename,@versions);
    $line = $_;
    @data = split 'a',$line;
    @data = split ',',$data[1];
    $range = scalar @data;
    if($range == 1){
	$num_files = 1;
    }
    else{
	$num_files = $data[1] - $data[0] + 1;
    }
    for($i=0;$i<$num_files;$i++){
	# line: < D:\Vtune\blah\blah;2
	$line = <TMP>;
	chop $line;
	@filename = split '>',$line;
# TBD: Better guards
	if(!($filename[1] =~ /\bMon|\bTue|\bWed|\bThu|\bFri|\bSat|\bSun/)){
	    @filename = split ':',$filename[1];
	    @filename = split ';',$filename[1];
	    #filename[0] = file, filename[1] = version
	    @versions = (-1,$filename[1]);
	    if($do_individual){
		if($filename[0] =~ /\.c\Z|\.h\Z|\.frm\Z|\.bas\Z|\.cpp\Z|\.hpp\Z|\.rc\Z/i){
		    $changed_files{$filename[0]} = [ @versions ];
		}
	    }else{
		$changed_files{$filename[0]} = [ @versions ];
	    }
	}
    }
}
#--------------------------------------------------------------------------
# delete_file
# Files deleted from snapshot
# versions = current, -1
#--------------------------------------------------------------------------
sub delete_file{
    # del L1L2dL3. Only care about lines deleted from file 1
    local ($i,$num_files,$line,@data,$range,@filename,@versions);
    $line = $_;
    @data = split 'd',$line;
    @data = split ',',$data[0];
    $range = scalar @data;
    if($range == 1){
	$num_files = 1;
    }
    else{
	$num_files = $data[1] - $data[0] + 1;
    }
    for($i=0;$i<$num_files;$i++){
	# line: < D:\Vtune\blah\blah;2
	$line = <TMP>;
	chop $line;
	@filename = split '<',$line;
	if(!($filename[1] =~ /\bMon|\bTue|\bWed|\bThu|\bFri|\bSat|\bSun/)){
	    @filename = split ':',$filename[1];
	    @filename = split ';',$filename[1];
	    #filename[0] = file, filename[1] = version
	    @versions = ($filename[1],-1);
	    if($do_individual){
		if($filename[0] =~ /\.c\Z|\.h\Z|\.frm\Z|\.bas\Z|\.cpp\Z|\.hpp\Z|\.rc\Z/i){
		    $changed_files{$filename[0]} = [ @versions ];
		}
	    }else{
		$changed_files{$filename[0]} = [ @versions ];
	    }
	}
    }
}
#-----------------------------------------------------------------------
# change_file
# Version has changed in snapshot
# version = version old, version new
# Changes can also be add/deletes.
#-----------------------------------------------------------------------
sub change_file{
    # change L1L2cL3L4
    # if L2-L1 > L3-L4, change and delete
    # if L3-L4 > L2-L1, change and add
    # if =, change only
    local($i,$j,$num_files1,$num_files2,$line,@data1,@data2,$range,@filename,@versions);
    $line = $_;
    @data = split 'c',$line;
    @data1 = split ',',$data[0];
    @data2 = split ',',$data[1];
    if(scalar @data1 == 1){
	$num_files1 = 1;
    }
    else{
	$num_files1 = $data1[1] - $data1[0] + 1;
    }
    if(scalar @data2 == 1){
	$num_files2 = 1;
    }
    else{
	$num_files2 = $data2[1] - $data2[0] + 1;
    }
    # read in files and first version
    for($i=0;$i<$num_files1;$i++){
	# line: < D:\Vtune\blah\blah;2
	#       ---
	#       > D:\Vtune\blah\blah;3
	$line = <TMP>;
	chop $line;
	@filename = split '<',$line;
	if(!($filename[1] =~ /\bMon|\bTue|\bWed|\bThu|\bFri|\bSat|\bSun/)){
	    @filename = split ':',$filename[1];
	    @filename = split ';',$filename[1];
	    #filename[0] = file, filename[1] = version
	    @versions = ($filename[1],-1);
	    if($do_individual){
		if($filename[0] =~ /\.c\Z|\.h\Z|\.frm\Z|\.bas\Z|\.cpp\Z|\.hpp\Z/i){
		    $changed_files{$filename[0]} = [ @versions ];
		}
	    }else{
		$changed_files{$filename[0]} = [ @versions ];
	    }
	}
    }
    # throw away '---' separator
    $line = <TMP>;
    chop $line;
    # read in files and second version
    for($j=0;$j<$num_files2;$j++){
	$line = <TMP>;
	chop $line;
	@filename = split '>',$line;
	if(!($filename[1] =~ /\bMon|\bTue|\bWed|\bThu|\bFri|\bSat|\bSun/)){
	    @filename = split ':',$filename[1];
	    @filename = split ';',$filename[1];
	    #filename[0] = file, filename[1] = version
	    if($changed_files{$filename[0]}){
		$changed_files{$filename[0]}[1] = $filename[1];
	    }
	    else{
		# file added
		@versions = (-1,$filename[1]);
		if($do_individual){
		    if($filename[0] =~ /\.c\Z|\.h\Z|\.frm\Z|\.bas\Z|\.cpp\Z|\.hpp\Z/i){
			$changed_files{$filename[0]} = [ @versions ];
		    }
		}else{
		    $changed_files{$filename[0]} = [ @versions ];
		}
	    }
	}
    }
}
#-------------------------------------------------------------------------
# do_stats
# Use the changed_files hash to check out files and uses parse_diff to get
# the statistics.
# Put line info in fields 2,3,4 of array.
# where 2 = add, 3 = del, 4 = change
#-------------------------------------------------------------------------
sub do_stats
{
    local(@files,$i,$index,$path,@filename,$line,@stats);
    @files = keys %changed_files;
    foreach $files (@files)
    {
	# check out version 1
	@filename = split /\\/,$files;
	$index = (scalar @filename) - 1;
	$path="";
	for($i=0;$i<$index;$i++){
	    $path .= "$filename[$i]\\";
	}
	# added file stats
	if($changed_files{$files}[0] == -1){
	    print "hco -vn $changed_files{$files}[1]";
	    `hco -v -en "VTune 3.0 Model" -st Development -usr onitevtune -pw onitevtune -br -r -op as -pn "Check Out for Browse (Read-only)" -vp $path $filename[$index] -vn $changed_files{$files}[1]`;
	    if(-e $filename[$index]){
		if(-B $filename[$index]){
		    # Binary files not compared
		    print STDERR "b";
		    `rm -f $filename[$index]`;
		}else{
		    $line = `wc -l $filename[$index]"`;
		    `rm -f $filename[$index]`;
		    chop $line;
		    @stats = split ' ',$line;
		    $changed_files{$files}[2] = $stats[0];
		    $changed_files{$files}[3] = 0;
		    $changed_files{$files}[4] = 0;
		    print STDERR ".";
		}
	    }else{
		print STDERR "Check out error: @filename\n"
	    }
	}
	# deleted file stats
	elsif($changed_files{$files}[1] == -1){
	    `hco -v -en "VTune 3.0 Model" -st Development -usr onitevtune -pw onitevtune -br -r -op as -pn "Check Out for Browse (Read-only)" -vp $path $filename[$index] -vn $changed_files{$files}[0]`;
	    if(-e $filename[$index]){
		if(-B $filename[$index]){
		    # binary file
		    print STDERR "b";
		    `rm -f $filename[$index]`;
		}else{
		    $line = `wc -l $filename[$index]"`;
		    chop $line;
		    @stats = split ' ',$line;
		    $changed_files{$files}[2] = 0;
		    $changed_files{$files}[3] = $stats[0];
		    $changed_files{$files}[4] = 0;
		    print STDERR ".";
		    `rm -f $filename[$index]`;
		}
	    }else{
		print STDERR "Check out error: @filename\n";
	    }
	}
	# change file stats
	else{
	    `hco -v -en "VTune 3.0 Model" -st Development -usr onitevtune -pw onitevtune -br -r -op as -pn "Check Out for Browse (Read-only)" -vp $path $filename[$index] -vn $changed_files{$files}[0]`;
	    if(-e $filename[$index]){
		if(-B $filename[$index]){
		    # binary file
		    print STDERR "b";
		    `rm -f $filename[$index]`;
		}else{
		    `mv -f $filename[$index] $filename[$index].tmp`;
		    `hco -v -en "VTune 3.0 Model" -st Development -usr onitevtune -pw onitevtune -br -r -op as -pn "Check Out for Browse (Read-only)" -vp $path $filename[$index] -vn $changed_files{$files}[1]`;
		    $line = &parse_diff($filename[$index].".tmp",$filename[$index]);
		    @stats = split '/',$line;
		    $changed_files{$files}[2] = $stats[0];
		    $changed_files{$files}[3] = $stats[1];
		    $changed_files{$files}[4] = $stats[2];
		    print STDERR ".";
		    `rm -f $filename[$index] $filename[$index].tmp`;
		}
	    }else{
		print STDERR "Check out error: @filename\n";
	    }
	}
    }
    print STDERR "\n";
}

#--------------------------------------------------------------------------
# print_summary
# Prints the summary of the data to STDOUT. Accumulates the totals.
# If output file was given STDOUT redirected to output file.
#-------------------------------------------------------------------------
sub print_summary
{
    local(@files,$delta);
    if($do_summary){
	open(STDOUT,">$opt_o.sum") or die "Error: can't open $opt_o.sum for writing!\n";
	print STDOUT "Lines Statistics for $snap1 vs. $snap2\n";
	if($do_individual){
	    print STDOUT "Source files only\n";
	}
	print STDOUT "file\tver1\tver2\tlines_add\tlines_del\tlines_chg\tdelta\n";
    }
    @files = keys %changed_files;
    foreach $files (@files)
    {
	# Contents of %changed_files hash
	# [0]=ver1 [1]=ver2 [2]=lines+ [3]=lines- [4]=lines chg'd
	# Output: filename ver1 ver2 add del change delta
	print "$files\t$changed_files{$files}[0]\t$changed_files{$files}[1]";
	print "\t$changed_files{$files}[2]\t$changed_files{$files}[3]\t";
	print "$changed_files{$files}[4]\t";
	$delta = $changed_files{$files}[2] - $changed_files{$files}[3];
	print "$delta\n";
	$total_added += $changed_files{$files}[2];
	$total_deleted += $changed_files{$files}[3];
	$total_changed += $changed_files{$files}[4];
    }
    print "\nTotals\n";
    print "\t\t$total_added\t$total_deleted\t$total_changed\n\n";
}
###########################################################################
#
# main code
#
###########################################################################

require "getopts.pl";

# %changed_files is an associative hash indexed by filename containing an
#                array with version1 and version2 of the file.

sub usage
{
    print STDERR "Usage:\n";
    print STDERR "-h       help\n";
    print STDERR "-1 FILE  input file, snapshot1\n";
    print STDERR "-2 FILE  input file, snapshot2\n";
    print STDERR "-s       source files only (.c,.h,.frm,.bas,.cpp,.hpp,.rc)\n";
    print STDERR "-o FILE  writes the summary for the change log to FILE.sum\n";
    print STDERR " > vstats.pl snapshot1 snapshot2\n";
    exit(1);
    return;
}

sub parse_args
{
    &Getopts('ho:1:2:s');
    &usage if ($opt_h);

    die "Error: no input files specified.\n"
        if($opt_1 eq "" || $opt_2 eq "");

    if($opt_o eq ""){
	print STDERR "WARNING: No filename entered for summary file. No summary files written.\n";
    }
    else{
	$do_summary = 1;
    }
    $snap1 = $opt_1;
    $snap2 = $opt_2;
    if($opt_s){
	print STDERR "Source files only.\n";
	$do_individual = 1;
    }
}

sub main
{
    my($name);
    local($line,$numfiles);
    &parse_args;
#    print $hco_cmd, "\n";
    $total_files_added = $total_files_deleted = $total_files_modified = 0;
    
    `diff -b $snap1 $snap2 > tmp.diff`;
    open(TMP,"<tmp.diff") or die "(main) Error: can't open tmp.diff for reading!\n";
    # Read files and version numbers into an array.
    while(<TMP>){
	chop;
	$line = $_;
	if($line =~ /\A\d*[,|a|c|d]/){
	    if($line =~ /a/){
		# ADD FILE
		&add_file($line);
		$total_files_added += 1;
	    }
	    elsif($line =~ /d/){
		# DELETE FILE
		&delete_file($line);
		$total_files_delted += 1;
	    }
	    elsif($line =~ /c/){
		# CHANGE FILE
		&change_file($line);
		$total_files_modified += 1;
	    }
	    else{
		print "Not reached in main\n";
	    }
	}
    }
# TBD: Added the following lines as deleted files
# > E0318 Cannot check out item lips32\test\Usp\bc50\readme.txt, it is deleted  
# TBD: Skip over the following lines
# <  |                    State  Test & RC Builds
    close TMP;
#    `rm -f tmp.diff`;
    
    &do_stats;
    &print_summary;
    print STDERR "Total files a/d/c: $total_files_added/$total_files_deleted/$total_files_modified\n";
    if($do_individual){
	print STDOUT "Total files a/d/c: $total_files_added/$total_files_deleted/$total_files_modified\n";
    }
}#end main

&main;
exit;





