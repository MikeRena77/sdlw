#!/usr/local/perl5/bin/perl -w
#
# @(#)/ta_workbench/hv_notify_package;15: Production Tech Arch 04/20/2001;15:53:20 Bruce Albrecht
#
#
# FINGERHUT Corporation
# Proprietary Source
#
# TEAM:     Technical Architecture
# FILE:     hv_notify_package
# AUTHOR:   Bruce Albrecht
# CREATED:  09/13/96
# REMARKS:  Provide email notification when package is promoted or approved
#
#
# HISTORY:
# who               when            what
# -----------       --------        --------------------------------------
# Bruce Albrecht    06/25/98        Rewrite to support environment user list,
#                                   use stdin as email message text, generate
#                                   list of users/groups approved or not
#                                   approved.
#
#

use strict;
use DBI (qw(:sql_types));
use Net::SMTP;
use FindBin;
use lib ($FindBin::RealBin);
use Hv_lookup_email;

# Site customizations:
my $maildomain = "mydomain.com";  # change this to your domain
my @mailhosts = ("mail1.mydomain.com", "mail2.mydomain.com"); # Change this to  the list of your SMTP mailhosts
my $harvest_user = "harrep";  # Change this to your Oracle user with select privileges
my $harvest_pw = "harvest";   # Change this to the password of the above Oracle user
my $DB_connect = "Oracle";    # Change to "Odbc" if "Odbc";
my $harvest_admin = 'cmadmin@mydomain.com';  # Change to your Harvest administrator email user
# $ENV{TWO_TASK} = "harvestDB";  # Remove comment and change to your database instance
                                # if on NT

# No further site customization should be required.

sub find_approvalnotes();
sub find_approvals();
sub find_date_package_in_state($ );
sub find_forms();
sub find_packagenotes();
sub find_versions($ );
sub lookup_packageobjid($ );
sub lookup_user(@);
sub dummy { 1 };
sub wrap($$$);

# Save the first four parameters
my ($environment, $state, $user, $next_state) = splice @ARGV, 0, 4;

my (@mailto_users, @mailto_groups, $versions, $approved, $notapproved,
	$suppress, $notes, $line, $dbh, $csr, $envobjid, %addresses, $statement,
	%pkgid, $packagenotes, $approvalnotes, $username, $envusrlist,
	%package_date, %username, %realname, $version_list, $versionnote_list,
	$pkgid_csr, $user_csr, $hist_csr, $package_list, $forms_list, $key,
	$show_merged_branches, $ignore_env_userlist, @packages, $sent);

# Each keyword value is an array of a subroutine to initialize the
# value, and the reference to the substitution value

my (%keywords) = ('user' => [\&dummy, \$user],
				  'username' => [\&dummy, \$username],
				  'environment' => [\&dummy, \$environment],
				  'state' => [\&dummy, \$state],
				  'nextstate' => [\&dummy, \$next_state],
				  'version' => [ sub {find_versions(0)}, \$version_list],
				  'package' => [sub {$package_list="  ".join("\n  ", @packages)
									   unless $package_list}, \$package_list],
				  'approved' => [ \&find_approvals, \$approved],
				  'notapproved' => [ \&find_approvals, \$notapproved],
				  'packagenote' => [ \&find_packagenotes, \$packagenotes],
				  'approvalnote' => [ \&find_approvalnotes, \$approvalnotes],
				  'versionnote' => [sub {find_versions(1)}, \$versionnote_list],
				  'form' => [ \&find_forms, \$forms_list],
				 );
my %vstatus = (N => "", R => "<reserved>", M => "<merged>", D => "<deleted>");

# This hash contains the parameter option as a key, and the data structure storing the option.
my %options = ( -users => \@mailto_users, -groups => \@mailto_groups,
				-packages => \@packages, -suppress => \$suppress,
				-ignore_env_userlist => \$ignore_env_userlist,
				-show_merged_branched => \$show_merged_branches );

# parse the rest of the parameters

while (@ARGV)
{
  my $ref = $options{shift @ARGV};

  if (ref $ref eq "ARRAY")
  {
	# push the all the arguments up to the next parameter that starts with 
	# "-" unto the end of the array associated with the option
	push @$ref, shift @ARGV while (@ARGV && substr($ARGV[0], 0, 1) ne "-");
  }
  elsif (ref $ref eq "SCALAR")
  {
	# set the variable associated with the option
	$$ref = 1;
  }
  else
  {
	# not an expected option, force program to die with usage message
	@packages = @mailto_users = @mailto_groups = ();
	last;
  }
}

die "Usage: $0 <Environment> <state> <user> <next_state> [-suppress] [-show_merged_branches] [-ignore_env_userlist] -users user ... user -groups group ... group -packages <packages> \n"
  unless @packages && (@mailto_users || @mailto_groups);

$ENV{TWO_TASK} = $ENV{ORACLE_SID} if $ENV{ORACLE_SID};

# connect to database
$dbh = DBI->connect("dbi:$DB_connect:$ENV{TWO_TASK}", $harvest_user, $harvest_pw) or
  die "Can't connect to data source:  $DBI::errstr\n";

# get environment objid and whether there's an environment user list
$csr = $dbh->prepare( $statement = qq{
  select envobjid, envuserlist
	from harenvironment
	  where environmentname = } . $dbh->quote($environment)
  ) || die "Can't prepare statement: $DBI::errstr";

$csr->execute || die "Can't execute statement: $DBI::errstr\n";

($envobjid, $envusrlist) = $csr->fetchrow_array;
die "Can't find environment: $DBI::errstr\n" unless $envobjid;
$csr->finish;
$envusrlist = $envusrlist eq "Y" && ! $ignore_env_userlist;

# Get name of person running UDP
$csr = $dbh->prepare( $statement = qq{
  select realname from haruser where username = } . $dbh->quote($user)) ||
  die "Can't prepare statement: $DBI::errstr";

$csr->execute || die "Can't execute statement: $DBI::errstr\n";
($username) = $csr->fetchrow_array;
$csr->finish;
$username =~ s/\s+$//;

# Save email for users in hash so that user doesn't get several emails
# because the user is in several groups and/or specified explicitly.

%addresses = map { lc($_), 1} get_email_user($dbh, @mailto_users),
  get_email_group_env($dbh, $envusrlist ? $envobjid : 0, @mailto_groups);

die "$0: Nobody to send to!" unless %addresses;

# If we're unable to send email for some reason, sleep and retry
# a couple times before giving up.
send_email:
foreach my $retry(0, 30, 60, 120, 120)
{
  sleep $retry;
 mailhosts:
  for my $mailhost(@mailhosts)
  {
	# Create new connection to mail host
	my $smtp = Net::SMTP->new($mailhost) or next mailhosts;

	$smtp->mail($harvest_admin) or next mailhosts;

	foreach (keys %addresses)
	{
	  $smtp->recipient($_) or warn "Unable to send mail to $_.\n";
	}

	$smtp->data() or next mailhosts;

	$smtp->datasend(generate_message_id($smtp->domain),generate_date_header)
	  or next mailhosts;

	if ($suppress)
	{
	  $statement="To: <Recipient list suppressed>";
	}
	else
	{
	  $statement="To: ";
	  for (keys %addresses)
	  {
		if (length($statement)+length($_) > 78)
		{
		  $smtp->datasend($statement,",\n") or next mailhosts;
		  $statement = "    " . $_;
		}
		else
		{
		  $statement .= ", " . $_;
		}
	  }
	}
	$smtp->datasend($statement,"\n") or next mailhosts;

	while (defined($line = <STDIN>))
	{
	  my @subs = $line =~ /\[([^\]]+)\]/g;
	  foreach my $key(@subs)
	  {
		my $sub = "";
		if ($keywords{$key})
		{
		  my ($func, $ref_var) = @{$keywords{$key}};
		  # call function to get information unless it's already been called
		  $func->() unless defined $$ref_var;
		  $sub = $$ref_var;
		}
		$line =~ s/\[$key\]/$sub/g;
	  }
	  $smtp->datasend($line) or next mailhosts;
	}

	$smtp->dataend() or next mailhosts;
	$smtp->quit or next mailhosts;
	$sent = 1;
	last send_email;
  }
}

# clean up DB activity
$pkgid_csr->finish if $pkgid_csr;
$user_csr->finish if $user_csr;
$hist_csr->finish if $hist_csr;
$dbh->disconnect;

die "Unable to send email after 5 attempts\n" unless $sent;

exit 0;

sub find_versions($ )
{
  # This function populates $versionnote_list if the parameter passed is 1
  # or $version_list if the parameter passed is 0

  my ($notes) = @_;
  my $detail = $notes ? \$versionnote_list : \$version_list;
  my ($csr, @version, $path, $item, $mappedversion, $description, $package,
	  $pkgid, $user, $time, $status, $inbranch, $mv, $branch);

# SQL to get all versions for a specific package
  $csr = $dbh->prepare("
select pathfullname, itemname, mappedversion, description, hv.creationtime,
       hv.creatorid, versionstatus, inbranch
from harpathfullname hpf, harversion hv, haritem hi
where hpf.pathobjid = hi.pathobjid
and hi.itemobjid = hv.itemobjid
and hv.packageobjid = ?") or
			  die "Can't execute statement: $DBI::errstr\n";
# SQL to get mappedversion for a final version of a branch merged back into
# the main trunk
  $branch = $dbh->prepare("
select mappedversion
from harversion v, harmergedversion mv
where mv.versionobjid = v.versionobjid
and frombranch = ?") or
  die "Can't execute statement: $DBI::errstr\n";

# get the versions for this package
  foreach $package (@packages)
  {
	$pkgid = lookup_packageobjid($package);
	$csr->execute($pkgid) or die "Can't execute statement: $DBI::errstr\n";
	@version = ();
	
	# Get all the info for a version
	while (($path, $item, $mappedversion, $description, $time, $user,
			$status, $inbranch) = $csr->fetchrow_array)
	{
	  $path =~ s/\s+$//; # trim trailing blanks
	  $item =~ s/\s+$//;
	  $mappedversion =~ s/\s+$//;
	  $time =~ s/\+$//;
	  next if ! $show_merged_branches && $inbranch && $mappedversion =~ /\./;
	  $description = "" if ! $notes || # don't save notes for [version]
		!defined($description) || # description is NULL in Oracle
		$description =~ /^\s*$/; # description is only whitespace
	  $description = wrap("   ", 79, $description);
	  lookup_user($user);
	  $mv = "";
	  if ($inbranch)
	  {
		# Find out which version in main trunk was from this branch
		$branch->execute($inbranch);
		($mv) = $branch->fetchrow_array;
		$mv = "" unless $mv;
		$mv =~ s/\s+$//;
		$mv = "\n   Branch merged into /$path$item;$mv" .
		  ($description ? "" : "\n") if $mv;
	  }
	  # save the version and description for sorting
	  push @version, sprintf("%-40s %10s %s %s %s%s",
							  "/$path$item;$mappedversion", $vstatus{$status},
							  $time, $username{$user}, $realname{$user}, $mv) .
					  $description ? "\n    Version notes:\n$description" : "";
	}

	# Save sorted version list
	$$detail .= (@version ?
				 ( join("\n  ",
						"\nVersions associated with package '$package':\n  ",
						sort @version # sorted version by path
					   ) . "\n") : # otherwise ...
				 ("\nNo versions are associated with package '$package'.\n"));
  }
  $csr->finish;
}

sub lookup_packageobjid($ )
{
  # This function returns the package objid for a specific package name
  my ($package) = @_;
  my ($pkgid);

  unless ($pkgid_csr) # prepare cursor if it has never been done
  {
	$pkgid_csr=$dbh->prepare("
select packageobjid
from harpackage
where envobjid = $envobjid
and packagename = ?") or
			  die "Can't execute statement: $DBI::errstr\n";
  }

  unless ($pkgid{$package}) # if not known, look it up
  {
	$pkgid_csr->bind_param(1, $package, SQL_CHAR) or
	  die "Can't bind: $DBI::errstr\n";
	$pkgid_csr->execute or die "Can't execute statement: $DBI::errstr\n";
	
	($pkgid) = $pkgid_csr->fetchrow_array;
	die "Can't find package '$package'\n" unless $pkgid;
	$pkgid{$package} = $pkgid;
  }
  return $pkgid{$package};
}

sub lookup_user(@)
{
  # This function populates the %username and %realname hashes from a
  # userid, but does not return anything.

  # The lookup is against harAllUsers in case the user has been deleted.
  my ($usrobjid, $name, $realname);

  unless ($user_csr)
  {
	$user_csr = $dbh->prepare("
select username, realname
from harallusers
where usrobjid = ? ") or
		die "Can't prepare statement: $DBI::errstr\n";
  }

  foreach $usrobjid(@_)
  {
	next if $username{$usrobjid}; # already have it
	$user_csr->execute($usrobjid) or 
	  die "Can't execute statement: $DBI::errstr\n";
	($name, $realname) = $user_csr->fetchrow_array;
	($username{$usrobjid} = $name) =~ s/\s+$//;
	($realname{$usrobjid} = $realname) =~ s/\s+$//;;
  }
}

sub find_date_package_in_state($ )
{
  # This function returns the date the package most recently entered
  # this state.
  my ($package) = @_;
  my ($last_date);
  unless ($package_date{$package})
  {
	unless ($hist_csr)
	{
	  $hist_csr = $dbh->prepare("
select to_char(execdtime,'J.SSSSS')
 from harpkghistory
where packageobjid = ?
and (action like 'Created%' or
     action like 'Promoted%' or
     action like 'Demoted%' )
statename = ?") or  die "Can't prepare statement: $DBI::errstr\n";
	  # to_char(time, 'J.SSSSS') returns julian date.seconds since midnight
	  # and seconds since midnight is 0 filled, right justified
	}

	$last_date = 0;

	$hist_csr->execute($package, $state) or
	  die "Can't execute statement: $DBI::errstr\n";

	while((($_) = $hist_csr->fetchrow_array) && defined $_)
	{
	  $last_date = $_ if $last_date < $_;
	}
	die "Can't find package history for '$package'\n" unless $last_date;
	$package_date{$package} = $last_date;
  }
  return $package_date{$package};
}

sub find_approvals()
{
  # This function finds out all the approval statuses
  my ($csr, $isgroup, $usrobjid, $usrgrpobjid, $package, $pkgid,
	  $last_date, %user, %group, %usergroup, %reject, $name, $realname,
	  $csr1, $action, %groupname);

# SQL to get all approval requirements for this state
  $csr=$dbh->prepare("
select isgroup, usrobjid, usrgrpobjid
from harapprovelist hal, harstate hs
where hal.stateobjid = hs.stateobjid
and hs.envobjid = $envobjid
and hs.statename = " . $dbh->quote($state)) or
					die "Can't execute statement: $DBI::errstr\n";
	$csr->execute || die "Can't execute statement: $DBI::errstr\n";
	
  while ((($isgroup, $usrobjid, $usrgrpobjid) = $csr->fetchrow_array) &&
		 defined $isgroup)
  {
	$isgroup eq "N" ? $user{$usrobjid} = 0 : $group{$usrgrpobjid} = 0;
  }

  $csr->finish;

  # get user info if there are any specific users required for approval
  lookup_user(keys %user) if (%user);

  # get group info if there are any groups required for approval
  if (%group)
  {
	$csr = $dbh->prepare("
select usergroupname
from harusergroup
where usrgrpobjid = ?") or
  die "Can't execute statement: $DBI::errstr\n";
	foreach my $objid (keys %group)
	{
	  $csr->execute($objid) or die "Can't execute statement: $DBI::errstr\n";
	  ($groupname{$objid} = $csr->fetchrow_array) =~ s/\s+$//;
	}
	$csr->finish;
  }

# SQL for getting all approval actions after last date package moved to 
# this state
  $csr=$dbh->prepare("
select usrobjid, action from harapprovehist
where packageobjid = ?
and execdtime > to_date(?, 'J.SSSSS')
order by execdtime") or die "Can't execute statement: $DBI::errstr\n";

# SQL to get all user groups for this user
  $csr1 = $dbh->prepare("
select usrgrpobjid
from harusersingroup
where usrobjid = $usrobjid") or die "Can't execute statement: $DBI::errstr\n";

  # for each package, check for approvals
  foreach $package(@packages)
  {
	$pkgid = lookup_packageobjid($package);
	$last_date = find_date_package_in_state($pkgid);
	%user = map { $_, 0 } keys %user; # reset user approvals
	%group = map { $_, 0 } keys %group; # reset group approvals
	%reject = (); # reset rejects

	$csr->execute($pkgid, "$last_date") or
	  die "Can't execute statement: $DBI::errstr\n";

	while (($usrobjid, $action) = $csr->fetchrow_array)
	{
	  lookup_user($usrobjid); # get user's name
	  unless ($group{$usrobjid})
	  {
		# get groups the user belongs to, if we haven't already done so
		$csr1->execute($usrobjid) or
		  die "Can't execute statement: $DBI::errstr\n";

		push @{$usergroup{$usrobjid}}, $usrgrpobjid
		  while (($usrgrpobjid) = $csr1->fetchrow_array);
	  }
	  if ($action =~ /Reject/)
	  {
		# If it's been rejected, this same user must later approve, even if
		# the user's approval requirement is a group approval
		$reject{$usrobjid} = 1;
		$user{$usrobjid} = 0 if $user{$usrobjid};
	  }
	  else
	  {
		# flag individual approval
		$user{$usrobjid} ++ if defined($user{$usrobjid});
		foreach (@{$usergroup{$usrobjid}})
		{
		  $group{$_} ++ if defined($group{$_}); # flag group approval
		}
		$reject{$usrobjid} = 0 if $reject{$usrobjid}; # clear reject
	  }
	}
	
	if (grep($user{$_}, keys %user) || grep($group{$_}, keys %group))
	{
	  $approved .= join("\n  ",
						"The package '$package' has been approved by:",
						map("User:  $username{$_} ($realname{$_})",
							grep $user{$_}, keys %user),
						map("Group: $groupname{$_}",
							grep $group{$_}, keys %group)) . "\n";
	}
	else
	{
	  $approved .= "The package '$package' has not by approved by anyone.\n";
	}
	if (grep(! $user{$_}, keys %user) || grep($reject{$_}, keys %reject) ||
		grep(! $group{$_}, keys %group))
	{
	  # users that need to approve, or haven't approved after rejecting
	  # with duplicates removed
	  my %union = map {($_, 1)} grep(! $user{$_}, keys %user),
		grep $reject{$_}, keys %reject;

	  $notapproved .=
		join("\n  ",
			 "The package '$package' still needs to be approved by:",
			 map("User:  $username{$_} ($realname{$_})", keys %union),
			 map("Group: $groupname{$_}", grep ! $group{$_}, keys %group)) .
			   "\n";
	}
	else
	{
	  $notapproved .= "The package '$package' is not waiting for approvals.\n";
	}
  }
}

sub find_packagenotes()
{
  my ($csr, $note, $package);

  $packagenotes = "";

# SQL for getting packagenote
  $csr=$dbh->prepare("
select note
from harpackage
where packageobjid = ?") or die "Can't execute statement: $DBI::errstr\n";

  foreach $package (@packages)
  {
	$csr->execute(lookup_packageobjid($package)) or
	  die "Can't execute statement: $DBI::errstr\n";
	
	($note) = $csr->fetchrow_array;
	if ($note && $note !~ /^\s*$/)
	{
	  $packagenotes .= "Notes for package '$package':\n" .
		wrap("  ", 78, $note);
	}
  }
}

sub find_forms()
{
  my ($csr, $pkgid, $package, @forms, $name, $type);

  $forms_list = "";

  # SQL to get forms associated with package
  $csr = $dbh->prepare("
select formname, formtypename
from harform hf, harformtype hft, harassocpkg hap
where hf.formobjid = hap.formobjid
and hf.formtypeobjid = hft.formtypeobjid
and hap.assocpkgid = ?") or
				die "Can't prepare statement: $DBI::errstr\n";

  foreach $package(@packages)
  {
	@forms = ();
	$csr->execute(lookup_packageobjid($package)) or
	  die "Can't execute statement: $DBI::errstr\n";

	while(($name, $type) = $csr->fetchrow_array)
	{
	  $name =~ s/ +$//;
	  $type =~ s/ +$//;
	  push @forms, "$type: $name";
	}
	$forms_list .= join("\n  ","Forms associated with package '$package':",
						sort @forms) . "\n"  if @forms;
  }
}
sub find_approvalnotes()
{
  my ($csr, $note, $pkgid, $last_date, $package, $usrobjid, $action, $date);

  $approvalnotes = "";

  # SQL to get approval notes
  $csr = $dbh->prepare("
select usrobjid, action, note, to_char(execdtime, 'MON DD YYYY HH24:MI:SS')
from harapprovehist
where packageobjid = ?
and execdtime > to_date(?, 'J.SSSSS')
order by execdtime
") or die "Can't execute statement: $DBI::errstr\n";

  foreach $package (@packages)
  {
	$pkgid = lookup_packageobjid($package);
	$last_date = find_date_package_in_state($pkgid);
	$csr->execute($pkgid, $last_date) or
	  die "Can't execute statement: $DBI::errstr\n";

	while (($usrobjid, $action, $note, $date) = $csr->fetchrow_array)
	{
	  if (defined($note) && $note !~ /^\s*$/)
	  {
		$action =~ s/\s+$//;
		lookup_user($usrobjid);
		$approvalnotes .= ($action =~ /rej/i ? "Rejection" : "Approval") .
		  " notes for package '$package' made by\n  $username{$usrobjid} " .
			"($realname{$usrobjid}) on $date:\n";
		$approvalnotes .= wrap("  ", 79, $note);
	  }
	}
  }
}

sub wrap($$$)
{
  # function to wrap long lines into paragraphs using the formline function

  my ($indent, $columns, $text) = @_;
  my $result = "";
  local ($^A); # make this local so it doesn't mess up any other formatting

  foreach my $line (split(/\n/, $text))
  {
	if ($line)
	{
	  $^A = "";  # empty formatting accumulator
	  formline($indent.'^'.('<'x($columns-1))."~~\n", $line);
	  $result .= $^A; # append result from formline
	}
	else
	{
	  $result .= "\n"; # don't indent empty lines
	}
  }
  return $result;
}

__END__

=head1 NAME

hv_notify_package - send email to users about package promotion/approval

=head1 SYNOPSIS

B<hv_notify_package> I<environment> I<state> I<user> I<next_state> B<-users> I<user> [... I<user>] B<-groups> I<group> [... I<group>] B<-packages> I<package> [... I<package>]

=head1 DESCRIPTION

hv_notify_package is a perl script meant to be a replacement for the
notify linked process for package approvals and package promotions or
demotions.  This server-side UDP is selected instead of Notify as the pre- or
post-process link.  The command line parameters pass information about the
environment, state, the users and user groups to be notified, and the
list of packages.  Standard input contains the message subject and the
message text to be sent in the email, including a number of keywords
that can be expanded to describe more information about the packages
promoted or approved.

When setting up the UDP, the program line should be:

	<path of UDP> [environment] [state] [user] [nextstate] -show_merged_branches -suppress -ignore_env_userlist -user user1 user2 ... usern -group group1 group2 ... groupn -package [package]>

If only Harvest group members are to be notified, then -user should be
omitted (and vice-versa).

An example default input for a promotion notification:

	From: Harvest Administrator
	Subject:  Package promoted to [environment]/[nextstate]

	The following packages were promoted by [user] ([username]):
	[package]

	[versionnote]
	[packagenote]

An example default input for an approval notification:

	From: Harvest Administration
	Subject:  Package approved in [environment]/[state]

	The following packages were approved by [user] [username]:
	[package]

	[approved]
	[notapproved]

	[versionnote]
	[packagenote]
	[approvalnote]


=over 4

=item I<Environment>

The Harvest environment in which the package resides.

=item I<State>

The Harvest state in which the package resides.

=item I<User>

The user performing the operation.

=item I<Next_State>

If the operation is a promote, the state to which the package is
promoted.

=item I<-suppress>

If I<-suppress> is specified, the recipient list is not displayed
in the email headers.

=item I<-ignore_env_userlist>

By default, if the environment is set up with a user list, the email
notification is not sent to any member of a Harvest group that is not
in the environment's user list.  If this parameter is specified, the
email will be sent to every member of the Harvest group[s] specified.

=item I<-show_merged_branches>

When a branch gets merged into the main trunk, Harvest no longer displays
the branched versions.  If this parameter is specified, the versions from
merged branch will be displayed in [version] or [versionnote].

=item I<-users> I<user> [... I<user>]

The list of Harvest users to be notified.

=item I<-group> I<group> [... I<group>]

The list of Harvest groups to be notified.

=item I<-package> I<package> [... i<package>]

The list of packages.

=item Standard input

The text of the message is contained in standard input, and should
include a Subject: line at the beginning followed by two blank lines.
The following keywords in the standard input will be expanded:

=item [user]

The user issuing the operation.

=item [username]

The Real Name of the user issuing the operation.

=item [environment]

The environment of the operation.

=item [state]

The state of the operation.

=item [nextstate]

The next state of the operation, if applicable.

=item [version]

The versions associated with the package are listed for each package.  The version
creator and creation time are are listed.

=item [approved]

The users or groups which have approved the package are listed for
each package.

=item [notapproved]

The users or groups which have not approved the package are listed for
each package.  Note:  this list include any users or groups which have
approved a package, or any users who have rejected the package.

=item [packagenote]

The note for each package is listed.

=item [approvalnote]

The note for each approval/reject for the selected packages is listed.

=item [form]

The names of any associated forms are listed for each package.

=item [versionnote]

The versions associated with the package and any notes for the versions
are listed for each package.  If [versionnote] is specified in the input,
[version] is not necessary.

=back

=cut
