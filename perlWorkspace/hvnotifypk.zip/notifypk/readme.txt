Here's a perl script that replaces Notify linked processes for package
promotion/demotion or package approvals with a UDP that sends an user
defined email with a lot of information about the package, like
versions associated with the package, forms associated with the
package, package and approval notes, and who has approved the package
and who still needs to approve it.

This script requires perl5, DBI, DBD::Oracle, and Net::SMTP to be
installed.  I've tested this on Solaris, but it should run on NT with
the versions of perl available from CPAN (Comprehensive Perl Archive
Network), which I believe come with DBI and DBD::Oracle.  From what I
read on the net, it probably will not work with the versions of perl
for NT from ActiveState.

The script assumes that there is a harrep user (password harvest) but 
changing it only requires change to one line, and there's an SMTP mail 
server available, and changing the name of the mailserver is also a
one line change.

Bruce Albrecht
Fingerhut
bruce.albrecht@seag.fingerhut.com