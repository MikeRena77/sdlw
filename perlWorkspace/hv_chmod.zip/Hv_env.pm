#!/usr/local/bin/perl -w
#
# @(#)/ta_workbench/Hv_env.pm;0: Production Tech Arch 04/13/1999;12:16:07 Bruce Albrecht
#
#
# FINGERHUT Corporation
# Proprietary Source
#
# TEAM:     Technical Architecture
# FILE:     hv_notify_open_pr
# AUTHOR:   Bruce Albrecht
# CREATED:  09/13/96
#
#
# HISTORY:
# who               when            what
# -----------       --------        --------------------------------------
# Bruce Albrecht    06/12/97        
#
#

package Hv_env;

%Hv_env::Update = ("prodDB" => {"user" => "harvest", "password" => "harvest"},
					 "testDB" => {"user" => "harvest", "password" => "harvest"},
					);
%Hv_env::Select = ("prodDB" => {"user" => "harrep", "password" => "harvest"},
					 "testDB" => {"user" => "harrep", "password" => "harvest"},
					);

1;
