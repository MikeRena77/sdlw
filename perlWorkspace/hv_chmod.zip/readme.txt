NAME
    hv_set_file_permissions - set file permissions for versions

SYNOPSIS
    hv_set_file_permissions *Environment* *state* *version* ... *version*

DESCRIPTION
    This script changes the file permissions of files passed in the parameter list based on the
    change request in the standard input. The input can either be absolute, which changes the
    permissions to the specified value, or symbolic, which can either change the permissions to
    a specific value or add or remove permission bits.

      hv_set_file_permissions [environment] [state] [version]

    absolute permissions
        An absolute mode is specified using octal numbers

            nnnn
             where:

                  n         a number from 0 to 7.  An  absolute  mode  is
                            constructed from the OR of any of the follow-
                            ing modes:

                            0400      Allow read by owner.
                            0200      Allow write by owner.
                            0100      Allow execute by owner.
                            0700      Allow  read,  write,  and   execute
                                      (search) by owner.
                            0040      Allow read by group.
                            0020      Allow write by group.
                            0010      Allow execute by group.
                            0070      Allow  read,  write,  and   execute
                                      (search) by group.
                            0004      Allow read by others.
                            0002      Allow write by others.
                            0001      Allow execute by others.
                            0007      Allow  read,  write,  and   execute
                                      (search) by others.

    symbolic mode
             A symbolic mode specification has the following format:

                  chmod <symbolic-mode-list> file...

             where:  <symbolic-mode-list> is a comma-separated list (with
             no  intervening  whitespace) of symbolic mode expressions of
             the form:
                  [who] operator [permissions]

             Operations are performed in the order given.  Multiple  per-
             missions  letters  following  a  single  operator  cause the
             corresponding operations to be performed simultaneously.

                  who       zero or more of the characters u, g, o, and a
                            specifying   whose   permissions  are  to  be
                            changed or assigned:

                            u         user's permissions
                            g         group's permissions
                            o         others' permissions
                            a         all permissions (user,  group,  and
                                      other)

                            If who is omitted, it defaults to a, but  the
                            setting  of  the file mode creation mask (see
                            umask in sh(1) or csh(1)  for  more  informa-
                            tion)  is  taken  into  account.  When who is
                            omitted, chmod will not override the restric-
                            tions of your user mask.

                  operator  either +, -, or =, signifying how permissions
                            are to be changed:

                            +         Add permissions.

                                      If permissions is omitted,  nothing
                                      is added.

                                      If who is  omitted,  add  the  file
                                      mode  bits  represented  by permis-
                                      sions, except for  the  those  with
                                      corresponding bits in the file mode
                                      creation mask.

                                      If who is  present,  add  the  file
                                      mode  bits  represented by the per-
                                      missions.

                            -         Take away permissions.

                                      If permissions is omitted, do noth-
                                      ing.

                                      If who is omitted, clear  the  file
                                      mode  bits  represented  by permis-
                                      sions,  except   for   those   with
                                      corresponding bits in the file mode
                                      creation mask.

                                      If who is present, clear  the  file
                                      mode  bits  represented  by permis-
                                      sions.

                            =         Assign permissions absolutely.

                                      If who is omitted, clear  all  file
                                      mode bits; if who is present, clear
                                      the file mode bits  represented  by
                                      who.

                                      If permissions is omitted, do noth-
                                      ing else.

                                      If who is  omitted,  add  the  file
                                      mode  bits  represented  by permis-
                                      sions, except for  the  those  with
                                      corresponding bits in the file mode
                                      creation mask.

                                      If who is  present,  add  the  file
                                      mode  bits  represented  by permis-
                                      sions.

                            Unlike other symbolic operations,  =  has  an
                            absolute  effect  in that it resets all other
                            bits represented by  who.   Omitting  permis-
                            sions  is useful only with = to take away all
                            permissions.

                  permission
                            any compatible combination of  the  following
                            letters:

                            r         read permission
                            w         write permission
                            x         execute permission
                            l         mandatory locking
                            s         user or group set-ID
                            t         sticky bit
                            u,g,o     indicate that permission is  to  be
                                      taken  from the current user, group
                                      or other mode respectively.

                            Permissions to a file may vary  depending  on
                            your  user  identification  number  (UID)  or
                            group identification number  (GID).   Permis-
                            sions  are  described in three sequences each
                            having three characters:

                                 User    Group    Other
                                 rwx     rwx      rwx

                            This example (user,  group,  and  others  all
                            have permission to read, write, and execute a
                            given file) demonstrates two  categories  for
                            granting  permissions:   the access class and
                            the permissions themselves.

                            The letter s is only meaningful with u or  g,
                            and t only works with u.

