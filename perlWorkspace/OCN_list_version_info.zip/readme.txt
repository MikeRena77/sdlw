NAME
    OCN_list_version_info - list info for versions

SYNOPSIS
    OCN_list_version_info *Environment* *state* *version* ... *version*

DESCRIPTION
    This script displays the package, package state, size, file access and
    version notes for the selected versions. If items are selected instead
    of versions, it will display the information for each version of the
    item visible in the specified state. The script should be called as a
    server side UDP with the parameters:

      hv_list_version_notes [environment] [state] ["version"]

