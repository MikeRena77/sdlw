# @(#) /ta_workbench/Hv_package_dependency.pm;5: Package dependency routine
#
#
# FINGERHUT Corporation
# Proprietary Source
#
# TEAM:     Technical Architecture
# FILE:     Hv_package_dependency.pm
# AUTHOR:   Bruce Albrecht
# CREATED:  12/96
# REMARKS:         This module contains the following subroutines.
#                  - dependent_packages
#
# HISTORY:
# who           when            what
# -----------   --------        --------------------------------------
# B. Albrecht   12/03/96        Initial
#

package Hv_package_dependency;

use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw(dependent_packages);

use strict;
use DBI;

sub dependent_packages
{

  my ($dbh, $environment, $state, $next_state, @packages) = @_;
  my ($csr, $envobjid, $repositname, $repositobjid, $path, $name, %path,
	  $package, $package1, $state1, $stateorder1, $mappedversion1,
	  $package2, $state2, $stateorder2, $mappedversion2, $key, $owner, %package,
	  $state_order, $next_state_order, $mote, $cmote, $select, $stateobjid, $order,
	  %states, @states, %order, %dependencies);

  $csr=$dbh->prepare(<<SQL1) or die "bad select: $dbh->errstr\n";
select envobjid from 
harenvironment 
where environmentname = ${\$dbh->quote($environment)}
SQL1

  $csr->execute;
  ($envobjid) = $csr->fetchrow_array;
  die "Can't find environment: $dbh->errstr\n" unless $envobjid;
  
  # get all the paths from all repositories in the environment
$csr=$dbh->prepare(<<SQL2) or die "bad select: $dbh->errstr\n";
select hpfn.pathobjid, hpfn.pathfullname 
from harpathfullname hpfn, haritempath hip, harenvrepository her 
where hip.repositobjid = her.repositobjid
and hip.pathobjid = hpfn.pathobjid
and her.envobjid = $envobjid
SQL2

  $csr->execute;
  while (($path, $name) = $csr->fetchrow_array)
  {
    $name=~s/\s+$//;
    $path{$path}=$name;
  }
  
  foreach $package (@packages)
  {
    $package{$package} = 1;
  }
  
  # get the state orders for the current state and the next state
  $csr=$dbh->prepare(<<SQL3) or die "bad select: $dbh->errstr\n";
select stateobjid, statename, stateorder 
from harstate 
where envobjid = $envobjid
SQL3

  $csr->execute;
  
  while ( ($stateobjid, $name, $order) = $csr->fetchrow_array)
  {
	$name =~ s/\s+$//;
	$states{$stateobjid} = $name;
	$order{$stateobjid} = $order;
	$state_order = $order if $name eq $state;
	$next_state_order = $order if $name eq $next_state;
  }

  if ( $state_order < $next_state_order )
  {
	foreach $stateobjid ( keys %order )
	{
	  push (@states, $stateobjid) if ($order{$stateobjid} < $next_state_order);
	}
  }
  else
  {
	foreach $stateobjid ( keys %order )
	{
	  push (@states, $stateobjid) if ($order{$stateobjid} > $next_state_order);
	}
  }
  
  # generate a select which will only find files that might be dependent
$select=<<SQL4;
select hia.itemname, hia.pathobjid, hpa.packagename, hva.mappedversion,
       hpb.packagename, hpb.stateobjid, hvb.mappedversion
from harversion hva, harversion hvb, harpackage hpa, harpackage hpb, haritem hia
where hpa.packagename in ($ {\(join(",\n", map $dbh->quote($_), @packages))} )
and  hva.packageobjid != hvb.packageobjid
and  hva.itemobjid = hvb.itemobjid
and  hva.packageobjid = hpa.packageobjid 
and  hvb.packageobjid = hpb.packageobjid 
and  hva.envobjid = $envobjid
and  hva.itemobjid = hia.itemobjid
and  hpb.stateobjid in ( $ {\(join(", ", @states))} )
SQL4

  ;#print $select,"\n";;
$csr=$dbh->prepare( $select) or die "bad select: $dbh->errstr\n";
$csr->execute;

  while (($name, $path, $package1, $mappedversion1, $package2, $state2, 
		  $mappedversion2) = $csr->fetchrow_array)
  {
    $package1 =~ s/\s+$//;
    $package2 =~ s/\s+$//;
    next if $package{$package2};
    $mappedversion1 =~  s/\s+$//;
    $mappedversion2 =~  s/\s+$//;
	# if it's just reserved, there's no mappedversion
	next unless $mappedversion1 ne "" && $mappedversion2 ne ""; 
    next if ($mappedversion1 < $mappedversion2) == ($state_order < $next_state_order);
    $name =~ s/\s+$//;
	push(@{$dependencies{$package1}{$package2}}, 
		 "/$path{$path}$name;$mappedversion1,$mappedversion2,$states{$state2}");
  }
  return %dependencies;
}

__END__

=head1 NAME

hv_package_dependency.pm - Function to check packages for dependencies

=head1 SYNOPSIS

use Hv_package_dependency

=head1 DESCRIPTION

Hv_package_dependency contains the function package_dependency which 
returns a list of packages that are dependent on other packages.

For a package promotion, package A depends package B if package A and 
package B modify the same item, and the version in package A has a larger
mapped version number than the version in package B.  When package A
gets promoted to the next state, all of the changes to the item made by
package B are visible, unless the version in package A deletes them.  In
cases where the items changed in package A and package B are a subset of
the items changed in package B, promoting package A may cause 
inconsistencies that can result in software failures or build failures.

For a package demotion, package A depends package B if package A and 
package B modify the same item, and the version in package A has a smaller
mapped version number than the version in package B.  When package A
gets demoted to the next state, all of the changes to the item changed by
package B are visible, including any of the changes made by package A.


It is possible for package A to be dependent on package B and package
B to be dependent on package A.  This occurs when an item is changed by
package A, then the item is changed by package B, and then changed by 
package A again.  In this situation, the safest practice is to promote
or demote both packages at the same time.

=head1 PARAMETERS

package_dependency($dbh, $environment, $state, $next_state, @packages)

=over 4

=item $dbh

Oracle database handle.

=item $environment

Name of Harvest environment.

=item $state

Name of current Harvest state.

=item $next_state

Name of next Harvest state.  The package dependency function automatically
determines whether this is a demotion or promotion based on state order.

=item @packages

List of the package names to be promoted or demoted.

=back

=head1 RETURNS

If there are no dependent packages, an empty hash is returned.
If there are dependent packages, the function returns a hash
of the form:

%hash{package promoted}{dependent package}->[array of versions with dependencies]

The array of versions is formatted to a string with 3 comma separated elements,
which are "path/item;mappedversion" for the version in the promoted package,
the mapped version of the version in the package upon which it is dependent,
and the state of the package upon which it is dependent.

 $dependencies = {"package x" => 
                    {"dep package a" => [ "path/item;versionx,versiona,statea",
                                          "path/item;versionx,versiona,statea"],
                     "dep package b" => [ "path/item;versionx,versionb,stateb"]},
                  "package y" => 
                    {"dep package c" => [ "path/item;versiony,versionc,statec"]}
                 }

=cut
