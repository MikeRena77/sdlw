# ExplodePkg.pl
# perl script for NT to "explode" a package within an environment.
#
# usage:  put a copy of perl.exe and ExplodePkg.pl in $HARVESTHOME\bin on your NT server, and
# set up a server udp with the following program line:
# NT Harvest 3.x    perl.exe explodepkg.pl " [environment] " " [state] " " [package] " 
# NT Harvest 4.x    perl.exe explodepkg.pl  "[environment]"   "[state]"   "[package]"  
#
# Note that the spaces are required around the bracketed variables, but within the quotes
# this allows the system variables to be translated by harvest, yet allows values with
# spaces to be interpreted by perl as one arg rather than a list.  The extra space at the
# beginning and the extra space at the end are removed.
#
# Note that this script assumes that the source environment/state have a create package process
# with the name of "Create Duplicate", a promote process named "Promote to Test Script Development"
# and a promote process named "Promote to Test Script Development".

# The username/password for sqlplus requires read permission on the harvest tables
# Package names must not include whitespace

# specify the username and password for the read-only Oracle account
$username = HARREP;
$userpass = HARVEST;

# specify the username and password for a harvest account
$husername = harvest;
$huserpass = harvest;

# specify the location of the UDP files
$harvesthome = "$ENV{'HARVESTHOME'}";
$udpdir = "$harvesthome\\bin";

# read the arguments
# Harvest 3 with NT
#$env =     substr($ARGV[0],1,length($ARGV[0])-2);shift;
#$st =      substr($ARGV[0],1,length($ARGV[1])-2);shift;

# Harvest 4 with NT
$env = $ARGV[0];shift;
$st =  $ARGV[0];shift;

foreach $pkg (@ARGV)
{
   $pkg0 = "$pkg";
   $pkg1 = "$pkg" . "-1";
   $pkg2 = "$pkg" . "-2";

   print "Creating new package $pkg1 in environment $env, state $st...\n";
   system "hcp -usr \"$husername\" -pw \"$huserpass\" -en \"$env\" -st \"$st\" -pn \"Create Duplicate\" \"$pkg1\" ";
   print "Creating new package $pkg2 in environment $env, state $st...\n";
   system "hcp -usr \"$husername\" -pw \"$huserpass\" -en \"$env\" -st \"$st\" -pn \"Create Duplicate\" \"$pkg2\" ";
   # do an error check
   system "del hcp.log";

   print "Creating new associations...\n";
   system "plus33.exe -s $username/$userpass \@'$udpdir\\harexplodepkg.sql' '$env' '$pkg0' '$pkg1' '$pkg2'";

   print "Promoting package $pkg to Test Script Development State...\n";
   system "hpp -usr \"$husername\" -pw \"$huserpass\" -en \"$env\" -st \"$st\" -pn \"Promote to Test Script Development\" \"$pkg1\" ";
   print "Promoting package $pkg to Multimedia Development State...\n";
   system "hpp -usr \"$husername\" -pw \"$huserpass\" -en \"$env\" -st \"$st\" -pn \"Promote to Multimedia Development\" \"$pkg2\" ";
   # do an error check
   system "del hpp.log";
}
#system "del ExplodePkg.log";
print "Done.\n";
