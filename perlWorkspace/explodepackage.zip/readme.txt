ExplodePkg - David Cavanaugh - PLATINUM technology ALS PSG Consultant

A utility for CCC/Harvest to "explode" a package into copies in an environment.

How it works:

A Promote Package process is run to promote a base package to the Product Development
State.  The process has a Pre-Linked server-based UDP.  The UDP runs explodepkg.sh 
(UNIX shell) or explodepkg.pl (NT Perl) on the server machine.  The script runs hcp to 
create two new packages with the same base name with a "=1" and "-2" appended to the 
new package names. It then invokes sqlplus and executes a compiled procedure, passing 
in the environment name and the three package names.  The procedure performs table 
manipulation to make the new packages a 'clone' of the original. The new packages are 
given the same form associations as the original. The new packages are given the same 
history as the original. This UDP assumes that a "Create Duplicate Package" package 
creation process exists in the source environment/state, along with "Promote to Test 
Script Development" and "Promote to Multimedia Development" promote processes.

Usage:  

Modify the harexplodepkgproc.sql file, specifying on the last line (the GRANT) the username 
of your read-only CCC/Harvest Oracle database user. (HARREP is the default)

Log in to sqlplus with the harvest account and execute the script:
sqlplus HARVEST/PASSWORD @harexplodepkgproc.sql

Modify the explodepkg.sh or explodepkg.pl file, specifying on the $username and $userpass lines
username the user name and password password of your read-only CCC/Harvest Oracle database user.
(HARREP/HARVEST is the default)
Also specify on the $husername and $huserpass the user name and password of the Harvest
account to be used by hcp command.

Put explodepkg.sh, making sure it is executable, in $HARVESTHOME/bin on your UNIX server.
OR,
Put explodepkg.pl in %HARVESTHOME%\bin on your NT server.

In CCC/Harvest, set up a PromotePackage process, and pre-link server udp with the following 
program line:

UNIX:
explodepkg.sh [environment] [state] [package]
NT Harvest 3.x
perl.exe explodepkg.pl " [environment] " " [state] " " [package] " 
NT Harvest 4.x
perl.exe explodepkg.pl  "[environment]"   "[state]"   "[package]"  

Note that the spaces are required around the bracketed variables, but within the quotes
this allows the system variables to be translated by harvest, yet allows values with
spaces to be interpreted by perl as one arg rather than a list.  The extra space at the
beginning and the extra space at the end are removed.

This UDP assumes that a "Create Duplicate Package" package creation process exists in the source 
environment/state along with the "Promote to Test Script Development" and "Promote to Multimedia
Development" promote processes.
