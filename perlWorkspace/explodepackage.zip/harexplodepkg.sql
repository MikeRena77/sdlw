execute platinum.harexplodepkg('&1','&2','&3','&4');
exit;
