create or replace procedure harexplodepkg(
  from_env harenvironment.environmentname%type,
  pkg  harstate.statename%type,
  pkg1 harstate.statename%type,
  pkg2 harstate.statename%type ) is
  E1 harenvironment.envobjid%type;
  P0 harpackage.packageobjid%type;
  P1 harpackage.packageobjid%type;
  P2 harpackage.packageobjid%type;
begin
  select envobjid into E1 from harenvironment where environmentname = from_env;
  select packageobjid into P0 from harpackage where packagename = pkg  and envobjid = E1;
  select packageobjid into P1 from harpackage where packagename = pkg1 and envobjid = E1;
  select packageobjid into P2 from harpackage where packagename = pkg2 and envobjid = E1;
  insert into harassocpkg select formobjid,P1 from harassocpkg where assocpkgid = P0;
  insert into harassocpkg select formobjid,P2 from harassocpkg where assocpkgid = P0;
  delete from harpkghistory where packageobjid = P1 or packageobjid = P2;
  insert into harpkghistory
    select P1,statename,environmentname,execdtime,usrobjid,action
    from harpkghistory where packageobjid = P0;
  insert into harpkghistory
    select P2,statename,environmentname,execdtime,usrobjid,action
    from harpkghistory where packageobjid = P0;
  delete from harpkghistory where packageobjid = P1 and execdtime =
  (select max(execdtime) from harpkghistory where packageobjid = P1);
  delete from harpkghistory where packageobjid = P2 and execdtime =
  (select max(execdtime) from harpkghistory where packageobjid = P2);
end harexplodepkg;
/
grant execute on harexplodepkg to harrep;

