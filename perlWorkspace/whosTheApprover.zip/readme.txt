ListApprovers - Thanh Trieu - National Australia Bank

A UDP for CCC/Harvest to list outstanding approvals for the package before it
can be promoted successfully to the next state; 

Requirements:

CCC/Harvest 3.0 or later, Harvest server, Perl


Usage:

After selecting a package, execute the process
by hitting "process" on the horizontal tool bar on top of the Harvest screen, then select
the option "List Approbers" from the drop-down list. After the UDP is executed, the query
results are displayed on the Harvest log file screen. 


How it works:

When The stand-alone UDP is invoked, it runs approver.pl; Harvest passes to this perl script
the Environment name, State name and the Package name. The script runs sqlplus to access 
approver(s) information in the databases, to find out which users still need to approve a
package before it can be promoted.


Setup:  

Put approver.pl in the appropriate directory on your Harvest server.  

Create a new stand-alone UDP process with the following program line:
/perlpath/perl approver.pl [environment][state][package] and set it to run on the server.
Turn "Modifiable" off and leave the Default Input box empty.


Possible Future enhancements:

Fine tune the sql in order to improve the response time of the query. The sql involves 
joining several tables, there is room for improvements on how the sql is conducted.

There may be some obscure or unusual circumstances it does not work for. Please let me know 
if you find any. If a package is rejected it does not have the smart to ensure that the same 
person approve it. The script has been tested on Unix but not on NT. A few minor changes
should allow it to run on both


Feedback is welcome.

Thanh_Trieu@national.com.au
