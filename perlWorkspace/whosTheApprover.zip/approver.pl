#!/local/lang/perl/bin/perl
# #!/usr/local/bin/perl

######################################################
# This Perl scripts peforms the following validation #
#                                                    #
# 1) Check that the package has been approved before # 
#    get promoted                                    # 
#                                                    #
# 2) If package has not been approved, the script    # 
#    will display a list of names under the          # 
#    responsible approver group,                     #
#    This will help the Harvest user to find out who # 
#    can approve the package, without the need to go #  
#    through Harvest Admin                           #
#                                                    #  
#                                                    #
# ARGUMENTS:  - HARVEST Environment Name             #  
#             - HARVEST State Name                   #
#             - Package Name                         #
#                                                    #
#                                                    #
# v1  28Aug2001 Thanh Trieu   First version          #
#                                                    # 
######################################################

$name = "approver.pl";
$debug = 0;
printf "\nAll arguments  passed: @ARGV" if $debug;
printf "\nFirst argument passed: $ARGV[0]" if $debug;
printf "\nSecnd argument passed: $ARGV[1]" if $debug;
printf "\nThird argument passed: $ARGV[2]" if $debug;

$environment = $ARGV[0];
$state = $ARGV[1];
$package = $ARGV[2];
$appflag = 1;


Validate_Inputs();
if ($appflag == 2)
     {Print_Validation_Msg();
	exit;}

Get_Individual_Approvers();

foreach $appusers (@appusers)
      {	$appcount = 0;
		Check_If_Approved();
         	if ($appcount == 0)      
            	{$appflag = 0;
              	Print_Msg_2();
            	Get_Approvers_Details_2();
            	Print_Approvers_Details();}    }
	

Get_Approver_Group();

foreach $appgroup (@appgroup)
     
	
       {	$appcount = 0;
		Check_If_Approved_Group();
		if ($appcount == 0)      
            	{     $appflag = 0;
                    	Print_Msg();
            		Get_Approvers_Details();
            		Print_Approvers_Details();}  
	}

if ($appflag == 1)
     {Print_Null_Msg();}

`rm -f $t_sql1 $t_sql2 $t_sql3 $t_sql4 $t_sql5 $t_sql6`;


#####################
sub Validate_Inputs #
#####################

{	
	$cnt = length($package);
            
      if  ( $cnt == 0 )
		{$appflag = 2;}
}

########################
sub Get_Approver_Group #
########################
{
$t_sql1="/tmp/app$$_sql1";
open(sqlfile,">$t_sql1");
print sqlfile  " select U.usergroupname from \n";
print sqlfile  " harstate S,\n";
print sqlfile  " harenvironment E,\n";
print sqlfile  " harpackage P,\n";
print sqlfile  " harapprovelist A,\n";
print sqlfile  " harusergroup U,\n";
print sqlfile  " harstateprocess B\n";
print sqlfile  " where  P.envobjid = E.envobjid \n";
print sqlfile  "  and P.stateobjid = S.stateobjid \n"; 
print sqlfile  "  and A.stateobjid = S.stateobjid \n"; 
print sqlfile  "  and B.stateobjid = S.stateobjid \n"; 
print sqlfile  "  and B.processtype = 'ApproveProcess'\n";
print sqlfile  "  and B.processobjid = A.processobjid \n";
print sqlfile  "  and P.packagename = '$package'\n";
print sqlfile  "  and P.approved = 'N' \n";
print sqlfile  "  and E.environmentname = '$environment'\n"; 
print sqlfile  "  and S.statename = '$state'\n";
print sqlfile  "  and A.usrgrpobjid = U.usrgrpobjid\n"; 
close (sqlfile);
@appgroup = `hsql -usr HARVESTR -pw harvestr -nh -t -f $t_sql1 2>/dev/null`;

{foreach (@appgroup)
  {printf "$_" if $debug;}}

}

###########################
sub Get_Approvers_Details #
###########################
{
$t_sql2="/tmp/app$$_sql2";
open(sqlfile,">$t_sql2");
print sqlfile  " select U.realname, U.email from \n";
print sqlfile  " haruser U, \n";
print sqlfile  " harusergroup G, \n";
print sqlfile  " harusersingroup A \n";
print sqlfile  " where  G.usergroupname = '$appgroup'\n";
print sqlfile  " and G.usrgrpobjid = A.usrgrpobjid \n";
print sqlfile  " and U.usrobjid = A.usrobjid \n";
close (sqlfile);
@approvers = `hsql -usr HARVESTR -pw harvestr -nh -t -f $t_sql2 2>/dev/null`;

}


##################
sub Print_Msg    #
##################
{   
    ($appshort, $appsecond) = split(/\s/,$appgroup);
    print "\nPackage $package has not been approved";
    print " by Approver Group $appshort, needs approval"; 
    print " by any one of the following pepople:";
    print "\n\n";
   }

##################
sub Print_Msg_2  #
##################
{
    print "\nPackage $package has not been approved";
    print " by Approver(s)";
    print "\n";
   }

###################
sub Print_Null_Msg#
###################

{
    print "\nPackage $package has been approved by all approvers";
    print "\n\n";
   }

#########################
sub Print_Validation_Msg#
#########################

{
    print "\nPlease select Harvest Package ";
    print "\prior to performing this inquiry";
    print "\n\n";
   }


#############################
sub Print_Approvers_Details #
#############################

{
    foreach (@approvers)
   {
    printf "%-20s", $_;
   }

print "\n";}

##############################
sub Get_Individual_Approvers #
##############################

{
$t_sql3="/tmp/app$$_sql3";
open(sqlfile,">$t_sql3");
print sqlfile  " select A.usrobjid from \n";
print sqlfile  " harstate S,\n";
print sqlfile  " harenvironment E,\n";
print sqlfile  " harpackage P,\n";
print sqlfile  " harapprovelist A,\n";
print sqlfile  " harstateprocess B\n";
print sqlfile  " where  P.envobjid = E.envobjid\n";
print sqlfile  "  and P.stateobjid = S.stateobjid \n";
print sqlfile  "  and A.stateobjid = S.stateobjid \n"; 
print sqlfile  "  and B.stateobjid = S.stateobjid \n"; 
print sqlfile  "  and B.processtype = 'ApproveProcess'\n";
print sqlfile  "  and B.processobjid = A.processobjid \n";
print sqlfile  "  and P.packagename = '$package'\n";
print sqlfile  "  and P.approved = 'N' \n";
print sqlfile  "  and E.environmentname = '$environment'\n"; 
print sqlfile  "  and S.statename = '$state'\n";
print sqlfile  "  and A.usrobjid not in (0)\n";
close (sqlfile);
@appusers = `hsql -usr HARVESTR -pw harvestr -nh -t -f $t_sql3 2>/dev/null`;

{foreach (@appusers)
  {printf "$_" if $debug;}}

}

	
############################
sub Get_Approvers_Details_2#
############################
{
$t_sql4="/tmp/app$$_sql4";
open(sqlfile,">$t_sql4");
print sqlfile  " select realname, email from \n";
print sqlfile  " haruser  \n";
print sqlfile  " where  \n";
print sqlfile " usrobjid = '$appusers' \n";
close (sqlfile);
@approvers = `hsql -usr HARVESTR -pw harvestr -nh -t -f $t_sql4 2>/dev/null`;

}

#######################
sub Check_If_Approved #
#######################
{
$t_sql5="/tmp/app$$_sql5";
open(sqlfile,">$t_sql5");
print sqlfile  " select count(*) from \n";
print sqlfile  " harpkghistory A,  \n";
print sqlfile  " harenvironment E,\n";
print sqlfile  " harstate S, \n";
print sqlfile  " harpackage P\n";
print sqlfile  " where  \n";
print sqlfile " A.action = 'Approved' \n";
print sqlfile " and A.usrobjid = $appusers";
print sqlfile " and P.packagename = '$package'\n";
print sqlfile " and E.environmentname = '$environment'\n"; 
print sqlfile " and P.envobjid = E.envobjid \n"; 
print sqlfile " and S.statename = '$state'\n";
print sqlfile " and S.envobjid = E.envobjid\n";
print sqlfile " and P.stateobjid = S.stateobjid\n";
print sqlfile " and A.packageobjid = P.packageobjid \n";
print sqlfile "  and A.execdtime > (select max(B.execdtime) \n";
print sqlfile "     from harpkghistory B\n";
print sqlfile "       where B.packageobjid = P.packageobjid\n";
print sqlfile "           and B.action not in\n"; 
print sqlfile "  ('Approved', 'Package name modified'))\n"; 
close (sqlfile);
$appcount = `hsql -usr HARVESTR -pw harvestr -nh -t -f $t_sql5 2>/dev/null`;

}

#############################
sub Check_If_Approved_Group #
#############################
{
$t_sql6="/tmp/app$$_sql6";
open(sqlfile,">$t_sql6");
print sqlfile  " select count(*) from \n";
print sqlfile  " harpkghistory A,  \n";
print sqlfile  " harusersingroup U, \n";
print sqlfile  " harenvironment E,\n";
print sqlfile  " harstate S, \n";
print sqlfile  " harusergroup C, \n"; 
print sqlfile  " harpackage P\n";
print sqlfile  " where  \n";
print sqlfile " A.action = 'Approved' \n";
print sqlfile " and A.usrobjid = U.usrobjid\n";
print sqlfile " and C.usergroupname = '$appgroup'\n"; 
print sqlfile " and U.usrgrpobjid = C.usrgrpobjid \n"; 
print sqlfile " and P.packagename = '$package'\n";
print sqlfile " and E.environmentname = '$environment'\n"; 
print sqlfile " and P.envobjid = E.envobjid \n"; 
print sqlfile " and S.statename = '$state'\n";
print sqlfile " and S.envobjid = E.envobjid\n";
print sqlfile " and P.stateobjid = S.stateobjid\n";
print sqlfile " and A.packageobjid = P.packageobjid \n";
print sqlfile "  and A.execdtime > (select max(B.execdtime) \n";
print sqlfile "     from harpkghistory B\n";
print sqlfile "       where B.packageobjid = P.packageobjid\n";
print sqlfile "           and B.action not in\n"; 
print sqlfile "  ('Approved', 'Package name modified'))\n";  
close (sqlfile);
$appcount = `hsql -usr HARVESTR -pw harvestr -nh -t -f $t_sql6 2>/dev/null`;

}

