Here's a perl script that replaces Notify linked processes for package
promotion/demotion or package approvals with a UDP that sends an user
defined email with a lot of information about the package, like
versions associated with the package, forms associated with the
package, package and approval notes, and who has approved the package
and who still needs to approve it.

This script requires perl5, DBI, DBD::Oracle, and Net::SMTP to be
installed.  I've tested this on Solaris and Windows 2000.  For Unix
servers, if your perl does not have these packages installed,
it might be simpler to install a local version of perl on the
server box and run perl -MCPAN -e shell and install DBI, DBD::Oracle 
and LWP.  Building DBD::Oracle requires that you have Oracle installed
the build box, and can compile C programs with your Oracle installation.
Windows users should be able to use ActiveState Perl, and install the DBI
and DBD::Oracle packages with ppt.  I am pretty sure Net::SMTP is part
of the base ActiveState perl.



Bruce Albrecht
Blue Cross Blue Shield of Minnesota
bruce_albrecht@bluecrossmn.com