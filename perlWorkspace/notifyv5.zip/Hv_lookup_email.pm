#!/usr/local/bin/perl -w
#
# @(#)[viewpath]/[item];[version]: [state] [environment] [crtime] [author]
#
#
# FINGERHUT Corporation
# Proprietary Source
#
# TEAM:     Technical Architecture
# FILE:     Hv_lookup_email.pm
# AUTHOR:   Bruce Albrecht
# CREATED:  09/13/96
#
#
# HISTORY:
# who               when            what
# -----------       --------        --------------------------------------
# Bruce Albrecht    06/12/97        Added headers
#
#

package Hv_lookup_email;
require 5.000;
require Exporter;
use DBI (qw(:sql_types));


@ISA = qw(Exporter);
@EXPORT = qw(get_email_group get_email_user generate_message_id generate_date_header
			 get_email_group_env get_email_user_env);

my %env_user = (0 => "N");

=head1 NAME

get_email_group - return list of user email addresses from Harvest group

=head1 SYNOPSIS

get_email_group($db_handle, @group)

=head1 DESCRIPTION

Return list of email address from the Harvest group specified.

=over 4

=item $db_handle

Database handle

=item @group

Scalar, list or array of Harvest groups.

=back

=cut

sub get_email_group ($;@)
{
  my($dbh, @group) = @_;
  
  get_email_group_env($dbh, 0, @group);
}

=head1 NAME

get_email_group_env

=head1 SYNOPSIS

get_email_group_env($db_handle, $envobjid, @group)

=head1 DESCRIPTION

Return list of email address from the Harvest group specified, excluding group
members not in specified Harvest environment's user list.

=over 4

=item $db_handle

Database handle

=item $envobjid

Harvest environment objid.  If value is zero, return all email addresses of all
members of the group

=item @group

Scalar, list or array of Harvest groups.

=back

=cut

#';

sub get_email_group_env ($$;@)
{
  my($dbh, $envobjid, @group) = @_;
  my($csr, $email, %list);


	$csr=$dbh->prepare("select email
from haruser u, harusersingroup uig, harusergroup ug
where ug.usergroupname = ?
and uig.usrgrpobjid = ug.usrgrpobjid
and uig.usrobjid = u.usrobjid"
					  ) or die "bad select: $dbh->errstr\n" ;


  foreach (@group)
  {
	$csr->bind_param(1, $_, SQL_CHAR);
	$csr->execute;
	while (($email) = $csr->fetchrow_array)
	{
	  $list{lc $email} = 1 if defined($email) && $email !~ /^\s*$/;
	}
  }
  $csr->finish;
  return keys %list;
}

=head1 NAME

get_email_user

=head1 SYNOPSIS

get_email_user($db_handle, $envobjid, @group)

=head1 DESCRIPTION

Return list of email address from the Harvest users specified.

=over 4

=item $db_handle

Database handle

=item @group

Scalar, list or array of Harvest users.

=back

=cut

sub get_email_user ($;@)
{
  my ($dbh, @user) = @_;
  get_email_user_env($dbh, 0, @user);
}

=head1 NAME

get_email_user_env

=head1 SYNOPSIS

get_email_user_env($db_handle, $envobjid, @group)

=head1 DESCRIPTION

Return list of email address from the Harvest users specified, excluding group
members not in specified Harvest environment's user list.

=over 4

=item $db_handle

Database handle

=item $envobjid

Harvest environment objid.  If value is zero, return all email addresses of all
users specified

=item @group

Scalar, list or array of Harvest users.

=back

=cut

#';
sub get_email_user_env ($$;@)
{
  my ($dbh, $envobjid, @user) = @_;
  my ($csr, $email, @list);
  
	$csr = $dbh->prepare("select email from haruser where username = ?")
	  or die "bad select: $dbh->errstr\n" ;

  foreach (@user)
  {
	$csr->bind_param(1, $_, SQL_CHAR);
	$csr->execute;
	($email) = $csr->fetchrow_array;
	push (@list, $email) if defined($email) && $email !~ /^\s*$/;
  }
  $csr->finish;
  return @list;
}

sub generate_message_id ($ )
{
  return join "", "Message-ID: <", time, ".", int(rand(65536)), ".", $$, '@', $_[0], ">\n";
}

sub generate_date_header ()
{
  # Calculate the difference between GMT and localtime
my $time=time();
my @gt = gmtime($time);
my @lt = localtime($time);
my $offset_from_gmt = $lt[1]-$gt[1]+100*($lt[2]-$gt[2]+
							  24*(($lt[5]*365+(($lt[5]%3)==0)+$lt[7]) 
								  <=> ($gt[5]*365+(($gt[5]%3)==0)+$gt[7])));
# Ugly! But it accounts for day rollovers

return join "", "Date: ", (qw(Sun Mon Tue Wed Thu Fri Sat))[$lt[6]],
				", ", $lt[3], " ", 
				(qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec))[$lt[4]],
				" ", 1900+$lt[5], " ", join(":", map {sprintf "%02d", $_} @lt[2,1,0]),
				sprintf " %+05d\n", $offset_from_gmt;
}
1;
