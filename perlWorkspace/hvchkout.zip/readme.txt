Hv_checkout.pm is a perl module to figure out which files need to be
checked out when creating a reference directory.  hv_techarch_udp is
a sample UDP using Hv_checkout.
