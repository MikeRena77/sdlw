#!/usr/local/bin/perl -w
#
# @(#)/ta_workbench/Hv_checkout.pm;8: Production Tech Arch 04/19/1999;18:47:09 Bruce Albrecht
#
#
# FINGERHUT Corporation
# Proprietary Source
#
# TEAM:     Technical Architecture
# FILE:     Hv_checkout.pm
# AUTHOR:   Bruce Albrecht
# CREATED:  06/03/97
#
#
# HISTORY:
# who               when            what
# -----------       --------        --------------------------------------
# Bruce Albrecht    7/23/97         Original.
# Jackie Griffin    2/16/98			Reworked into functions, added ftp_files.
#
#

package Hv_checkout;
require 5.004;
require Exporter;
use DBI;
use Cwd;
use strict;

@Hv_checkout::ISA = qw(Exporter);
@Hv_checkout::EXPORT = qw(&create_co_list_query &create_co_list 
						  &checkout &ftp_files);

sub create_co_list_query( $$$*$$ );
sub create_co_list( $*$$ );
sub checkout( $$$$$$$*$ );
sub ftp_files( $$$$$$$$*;$ );
sub ftp_fsize( $$ );
sub query_environment( $$ );
sub query_repositories( $$$ );
sub query_packages( $$$$ );
sub query_view( $$$ );
sub my_mkdir( $$ );
sub footprint( $$$ );

use vars qw(%contents %co_list);
my $RETRY = 10;
			  
sub create_co_list_query($$$*$$)
{
  my ($dbh, $environment, $state) = splice @_, 0, 3;
  local *contents = shift;
  my ($rpackages, $rrepositories) = splice @_, 0, 2;
  
  my ($csr, $now, @gmtime, @localtime, $gmdiff, $cwd, $envobjid, $viewobjid,
	  $stateorder, %packageobjid, @repositobjid, $demote, %items, $item, $name,
	  $path, $version, $status, $select, %itemobjid);

  # calculate the difference between localtime and GMT.  Some of the Harvest date
  # fields are in GMT, so they don't jibe with sysdate.

  $now=time();
  @gmtime=(gmtime($now));
  @localtime=(localtime($now));
  $gmdiff=((($gmtime[5]*365+($gmtime[5]==0)+$gmtime[7])*24+$gmtime[2])-
	(($localtime[5]*365+($localtime[5]==0)+$localtime[7])*24+$localtime[2]))/24;
  $cwd = getcwd();

  # Find environment
  $envobjid = query_environment($dbh, $environment);
  
  # Get view associated with current state
  ($viewobjid, $stateorder) = query_view($dbh, $envobjid, $state);
 
  # Find repositories associated with this environment
  if ( @$rrepositories )
  {
	@repositobjid = query_repositories($dbh, $envobjid, $rrepositories);
  }

  # Get specified packages in this environment
  if ( @$rpackages )
  {
	($demote, %packageobjid) = query_packages($dbh, $envobjid, $rpackages, $stateorder);
  }

  # Now create a select statement to find all versions of any items 
  # modified by specified packages
  if (%packageobjid)
  {
	$select = "
select hi.itemobjid, hi.itemname, hpfn.pathfullname, 
       hv2.mappedversion, hv2.versionstatus
from harpathfullname hpfn, harversioninview hvv, harversion hv2, 
     harversion hv, haritem hi
where hi.itemobjid = hv.itemobjid
and    hi.pathobjid = hpfn.pathobjid
and    hv.envobjid = $envobjid
and    hv.itemobjid = hv2.itemobjid
and    hv2.versionstatus != 'R'
and    hv2.versionobjid = hvv.versionobjid
and    hvv.viewobjid = $viewobjid
and    hvv.intime <= sysdate+$gmdiff and hvv.outtime >= sysdate+$gmdiff
and    hv.packageobjid in (" . join(", ", keys %packageobjid) . ")
";
  }
  # Otherwise if no packages specified, select all versions in view
  else
  {
	# Get a list of all items that were created with a package
	if (@repositobjid)
	{
	  $select = "
select hi.itemobjid 
from harversion hv, haritem hi
where hi.itemobjid = hv.itemobjid
and   hv.packageobjid != 0
and   hv.mappedversion like '0 %'
and   hi.repositobjid in (" . join(", ", @repositobjid). ")";
	}
	else
	{
	  $select = "
select hi.itemobjid
from harversion hv, haritem hi, harenvrepository her
where her.envobjid = $envobjid
and   her.repositobjid = hi.repositobjid
and   hi.itemobjid = hv.itemobjid
and   hv.packageobjid != 0
and   hv.mappedversion like '0 %'";
	}
	
	$csr = $dbh->prepare($select) or
	  die "bad select: $dbh->errstr\n";
	$csr->execute;
	
	while(($item) = $csr->fetchrow_array)
	{
	  $itemobjid{$item} = 1;
	}
	
	# Get a list of all items in the repositories specified or for this
	# environment.  If there are no versions for an item, it was
	# created in the initial load, and is available across all views.

	if (@repositobjid)
	{
	  $select = "
select hi.itemobjid, hi.itemname, hpfn.pathfullname
from harpathfullname hpfn, haritem hi
where  hi.repositobjid in (" . join(", ", @repositobjid). " )
and    hi.pathobjid = hpfn.pathobjid
";
	}
	else
	{
	  $select = "
select hi.itemobjid, hi.itemname, hpfn.pathfullname
from harpathfullname hpfn, haritem hi, harenvrepository her
where  her.envobjid = $envobjid
and    hi.repositobjid = her.repositobjid
and    hi.pathobjid = hpfn.pathobjid
";
	}
	$csr = $dbh->prepare($select) or
	  die "bad select: $dbh->errstr\n";
	$csr->execute;
	
	while(($item, $name, $path) = $csr->fetchrow_array)
	{
	  $path =~ s-^([^/])-/$1-;
	  next if $itemobjid{$item};
	  $name =~ s/\s+$//;
	  @{$items{$item}} = (0, "N", $name);
	  push @{$contents{$path}}, $items{$item};
	}

	# Now generate the select for all the versions in this view.
	
	$select = "
select hi.itemobjid, hi.itemname, hpfn.pathfullname, 
       hv.mappedversion, hv.versionstatus
from harpathfullname hpfn, harversioninview hvv, 
     harversion hv, haritem hi
where hi.itemobjid = hv.itemobjid
and    hi.pathobjid = hpfn.pathobjid
and    hv.envobjid = $envobjid
and    hv.versionstatus != 'R'
and    hv.versionobjid = hvv.versionobjid(+)
and    ((hvv.viewobjid is null) or ((hvv.viewobjid = $viewobjid)
and    hvv.intime <= sysdate+$gmdiff and hvv.outtime >= sysdate+$gmdiff))
";
  }
  

  # Append repository selector to select string if repository objects found
  if ( @repositobjid )
  {
	$select .= "and   hi.repositobjid in (" . join(", ", @repositobjid) . ")\n"; 
  }

  # save information about the versions
  $csr = $dbh->prepare($select) || 
	die "bad select: $dbh->errstr\n";
  $csr->execute;
    
  while(($item, $name, $path, $version, $status) = $csr->fetchrow_array)
  {
	$path =~ s-^([^/])-/$1-;
	$version =~ s/\s+$//;
	$name =~ s/\s+$//;
	if ( ! $items{$item} )
	{
	  # new item
	  @{$items{$item}} = ($version, $status, $name);
	  push @{$contents{$path}}, $items{$item};
  	}
	elsif ( $version > $items{$item}[0] )
	{
	  # save status because the version is greater
	  $items{$item}[0] = $version;
	  $items{$item}[1] = $status;
	}
  }

  if ($demote)
  {
	# Anything found that's a new item needs to be deleted.
	$version = 0;
	$status = "D";
	
	$select="
select hi.itemobjid, hi.itemname, hpfn.pathfullname
from harpathfullname hpfn,harversion hv, haritem hi
where hi.itemobjid = hv.itemobjid
and    hi.pathobjid = hpfn.pathobjid
and    hv.envobjid = $envobjid
and    hv.packageobjid in (" . join(", ", keys %packageobjid) . ")
";
	$select .= "and   hi.repositobjid in (" . join(", ", @repositobjid) . ")\n" 
	  if @repositobjid;
	
	$csr = $dbh->prepare($select) or 
	  die "bad select: $dbh->errstr\n";
	$csr->execute;
	
	while(($item, $name, $path) = $csr->fetchrow_array)
	{
	  $name =~ s/\s+$//;
	  if ( ! $items{$item})
	  {
		# new item
		@{$items{$item}} = ($version, $status, $name);
		push @{$contents{$path}}, $items{$item};
	  }
	}
  }
}
			  

sub create_co_list($*$$)
{
  my $status = shift;
  local *contents = shift;
  my $rversions = shift;
  my $rrepositories = shift;
  my ($repos, $rfiles, $file, $version);
      
  # If repository list exists, need to compare prefix of files to repository
  #  name, so that if the repository name does not appear in the first segment
  #  of the file name, the file does not get included.
  
  if ( defined $rrepositories and @$rrepositories and @$rversions)
  {
	foreach $repos (@$rrepositories)
	{
	  push @$rfiles, (grep /^\/$repos/, @$rversions);
	}
  }
  else
  {
	  $rfiles = $rversions;
  }
  
  # For each file in list, if the status is Normal (not Delete), check for ;<version number>.
  #  If Normal and not found, don't include in array.
  foreach $file (@$rfiles)
  {
	$version = 0;
    if ($status eq "D")
	{
	  $file =~ m-^(.*)/(.*)-;
	  $version = $3 if defined $3;
	  push @{$contents{$1}}, [$version, $status, $2];
	}
	elsif ($status eq "N")
	{
	  $file =~ m-^(.*)/(.*);(\d+)$-;
	  if (defined $3)
	  {
		$version = $3;
		push @{$contents{$1}}, [$version, $status, $2];
	  }
	}
  }
}

sub my_mkdir($$)
{
  my ($file, $mode) = @_;
  my ($path, $subdir);
  
  $path="";
  foreach $subdir ( split("/", $file) )
  {
	$path .= "/$subdir";
	mkdir ($path, $mode) unless -d $path;
  }
}

sub query_environment($$)
{
  # Query harvest database for environment
  my ($dbh, $environment) = @_;
  my ($csr, $envobjid);

  # find environment
  $csr = $dbh->prepare("
select envobjid from harenvironment
where environmentname = " . $dbh->quote($environment))
	or die "bad select:  $dbh->errstr\n";
  $csr->execute;

  ($envobjid) = $csr->fetchrow_array;

  die "Can't find environment:  $dbh->errstr\n" unless defined $envobjid;
  $envobjid;
}

sub query_repositories($$$)
{
  # Query harvest database for named repositories in named environment
  my ($dbh, $envobjid, $repositories) = @_;
  my ($csr, $objid, @repositobjid, @dummy);
  
  $csr = $dbh->prepare("
select hr.repositobjid
from harenvrepository her, harrepository hr
where hr.repositobjid = her.repositobjid
and envobjid = $envobjid
and repositname in ( " . join(", ", map $dbh->quote($_), @$repositories) . ")"
					  )  || die "bad select:  $dbh->errstr\n";
  $csr->execute;
  
  push(@repositobjid, $objid) while(($objid) = $csr->fetchrow_array);

  return @repositobjid;
}

sub query_packages($$$$)
{
  # Query harvest database for named packages in named environment
  my ($dbh, $envobjid, $packages, $stateorder) = @_;
  my ($csr, $objid, $order, $demote, @dummy, %packageobjid);

  $csr = $dbh->prepare("
select packageobjid, stateorder
from harpackage hp, harstate hs
where hs.envobjid = $envobjid
and hs.stateobjid = hp.stateobjid
and packagename in (". join(", ", map $dbh->quote($_), @$packages) . ")"
				   )  or die "bad select:  $dbh->errstr\n";
  $csr->execute;

  $packageobjid{$objid} = $order while(($objid, $order) = $csr->fetchrow_array);

  # Set demote flag if any of the retrieved packages are in an earlier state
  # than the state specified.

  $demote = grep($_ < $stateorder, values %packageobjid);

  return($demote,%packageobjid);
}

sub query_view($$$)
{
  # Query harvest database for view associated with named state in named environment
  my ($dbh, $envobjid, $state) = @_;
  my ($csr, $viewobjid, $stateorder);

  $csr = $dbh->prepare("
select viewobjid, stateorder
from harstate 
where envobjid = $envobjid and statename = " . $dbh->quote($state)) 
	or die "bad select: $dbh->errstr\n" ;
  $csr->execute;
  
  ($viewobjid, $stateorder) = $csr->fetchrow_array;

  return($viewobjid, $stateorder);
}

sub checkout($$$$$$$*$)
{
  # Check out list of files
  my ($environment, $state, $base, $drop_leading_path, $quiet, $force, $footprint) = splice @_, 0, 7;
  local *contents = shift;
  my $hco_params = shift;

  my ($retry, @checkout_names, $path, $newpath, $name, $no_pid_count, $pid, @co_cmd);
  my $hco = $ENV{HARVESTHOME} . "/bin/hco";
  my $logfile = "cm_export.log";
  
  # Make sure base starts with /;
  $base =~ s-^([^/])-/$1-;
   
  foreach $path (sort keys %contents)
  {
	# cd to the appropriate subdirectory of the specified path,
	#  creating subdirectories as needed
	($newpath = $path) =~ s-^(/+[^/]*){$drop_leading_path}--;
	$newpath = $base . "/" . $newpath;
	$newpath =~ s-(/{2,})-/-g;
  	my_mkdir($newpath, 0755) unless -d $newpath;
	chdir $newpath;
	
	@checkout_names = ();
	my %co_info;
	
	# Now create checkout list
	#  If force is set, save then set file permissions to read only
	foreach ( @{$contents{$path}} )
	{
	  $name = $_->[2];
	  if ( $_->[1] eq "N" )
	  {
		$co_info{$name} = $_;
	  	if ( $force and -e $name and -f $name)
		{
		  $co_info{$name}->[4] =  (stat $name)[2];
		  if ( $co_info{$name}->[4] & 0222 )
		  {
			chmod $co_info{$name}->[4] & 0555, $name;
		  }
		}
		push @checkout_names, $name;
	  } 
	  elsif ( $_->[1] eq "D" and -f $name)
	  {
		print "Unable to delete: $newpath/$name\n" if not unlink $name;
	  }
	}

	# Now check the files out
	@co_cmd = ();
	if ( @checkout_names )
	{
	  $path =~ s-^([^/])-/$1-;
	  @co_cmd = ($hco, "-en", $environment, "-st", $state, @$hco_params, "-vp",
				 $path, @checkout_names);
	  unlink $logfile;
	  open(LOG, "> $logfile") or warn "Unable to open logfile: $newpath/$logfile\n" ;
      for ($retry = 5; $retry; sleep $retry)
	  {
		$retry = 5;
		open(CMD, "-|") || exec @co_cmd;
		print LOG join(" ", @co_cmd, "\n");
		while(<CMD>)
		{
		  print STDOUT $_ unless $quiet;
		  print LOG $_;
		  if ( /^I0301(\s*)Item (.*);/ )
		  {
			my ($name) = $2;
			$name =~ s-.*/--;
			$co_info{$name}->[3] = 1;
		  }

		  $retry = 0 if ($retry == 5);
		  $retry = 10 if (/^E(0060|0716|0701|9013|0102|1001)/);
		}

		# Generally if hco returns without any message at all, it is because
		# the .hsig file is bad.  
		unlink ".hsig" if $retry == 5; 
		close CMD;
	  }
	  close LOG;
	  
	  # Now go through and restore permissions of files that weren't successfully checked out.
	  if ( $force )
	  {
		foreach $name (grep(! $co_info{$_}->[3], @checkout_names))
		{
		  if ( $co_info{$name}->[4] ) { chmod $co_info{$name}->[4], $name; }
	  	} 
	  }
	  
	  # Final step-  if requested, run footprint on files that were checked out.
	  if ( $footprint )
	  {
		my (@fpnames) = grep($co_info{$_}->[3], @checkout_names);
		if ( @fpnames )	{ footprint($logfile, $quiet, \@fpnames); }
	  }
	}
  }
}

sub footprint($$$)
{
  my ($logfile, $quiet, $rnames) = @_;
  my $name;
  my $hft = "/usr/local/Harvest/bin/hft";
     
  open(LOG, ">> $logfile");
  foreach $name (@$rnames)
  {
	open(CMD, "-|") or 
	  (
		#redirect stderr to stdout before running hft
		open(STDERR, ">&STDOUT") && 
		exec $hft, $name
	  );
	  while(<CMD>)
	  {
		print STDOUT $_ unless $quiet;
		print LOG $_;
	  }
	  close CMD;
  }
  close LOG;
}


sub ftp_files($$$$$$$$*;$)
{
  use Net::FTP;
  use Time::HiRes qw ( time alarm sleep );
 
  # Ftp files contained in contents hash to remote machine and 
  # remote base directory, verifying size for each file transferred.
  # Return name and time and transfer speed so users can see that something happened.
  my($base, $drop_leading_path, $quiet, $checkout, $remote_host, $remote_user,
	 $remote_pw, $remote_base) = splice @_, 0, 8;
  local (*co_list) = splice @_, 0, 1;
  my ($usrfunc) = shift @_;
  my($ftp, $path, $lfsize, $rfsize, @rfdir, $name, $lpath, $rfile, $rbase, @sizelines,
	 $lfile, $badsize, @co_names, @rm_names, @ftp_names, $time1, $time2, $ttime, $trate, 
     $file_exists);
  
  # Set it up.
  open(STDERR, ">&STDOUT");
  chdir "$base" or warn("In ftp: can't change directories to $base."); 
  $ftp = Net::FTP->new($remote_host) 
	or warn("In ftp: can't connect to remote site $remote_host."); 
  $ftp->login($remote_user, $remote_pw)
	or warn("In ftp: unable to login to $remote_host as $remote_user.");
  $ftp->binary();

  foreach $path (keys %co_list)
  {
	($lpath = $path) =~ s-^(/+[^/]*){$drop_leading_path}/--;
	$lpath = $base . $lpath;
	$ftp->cwd("$remote_base/$lpath") or $ftp->mkdir("$remote_base/$lpath", 1); 
	$badsize = 0;

	# if $checkout set, only ftp the files that have been checked out
	@co_names = ();
    @rm_names = ();
	for ( @{$co_list{$path}} )
	{
	  if ((not $checkout) or $_->[3])
	  {
		$_->[1] eq 'N' ? push @co_names, $_->[2] : push @rm_names, $_->[2];   
	  }
	}

   	foreach $name (@co_names)
	{
	  # put the file, calculate transfer time, check size of transferred file
	  ( $rbase = "$remote_base/$lpath" )=~ s-(/{2,})-/-g;
	  ( $rfile = "$rbase/$name" ) =~ s-(/{2,})-/-g;
	  ( $lfile = "$base/$path/$name" ) =~ s-(/{2,})-/-g;
	  $time1 = time;
	  $ftp->put($lfile, $rfile);
	  &{$usrfunc}( $ftp, $rbase, $name ) if (defined $usrfunc);
	  $time2 = time;
	  $ttime = $time2 - $time1;
      ($rfsize, $file_exists) = ftp_fsize($ftp, $rfile);
	  if ( $file_exists and  ($rfsize != (-s $lfile)) )
	  {
		$ftp->delete($rfile);
		++$badsize;
		sleep 10;
		redo unless ($badsize > $RETRY);
		warn("In ftp: transfer failed - size mismatch of $lfile and $rfile.");
	  }
      elsif ( not $file_exists )
	  {
		++$badsize;
		sleep 10;
		redo unless ($badsize > $RETRY);
		warn("In ftp: unable to transfer $lfile to $rfile.");
	  }
	  elsif ( not $quiet )
	  {
		$trate = ($rfsize / $ttime) / 1024;
		printf("FTP Success! %s bytes transferred to %s in %.2f secs at %.2f Kbytes/sec.\n",
			   $rfsize, $rfile, $ttime, $trate);
	  }
	  $badsize = 0;
	  
	}
   	foreach $name (@rm_names)
	{
	  ( $rbase = "$remote_base/$lpath" ) =~ s-(/{2,})-/-g;
	  ( $rfile = "$rbase/$name" ) =~ s-(/{2,})-/-g;
      ( $rfsize, $file_exists ) = ftp_fsize($ftp, $rfile);
      if ( $file_exists )
	  {	  
		$ftp->delete($rfile);
		( $rfsize, $file_exists ) = ftp_fsize($ftp, $rfile);
		if ( $file_exists )
		{
		  ++$badsize;
		  sleep 10;
		  redo unless ($badsize > $RETRY);
		  warn("In ftp: unable to delete $rfile.\n");
		}
        if ( not $quiet and (not $file_exists) ) { print "FTP Success! $rfile deleted.\n"; }
	  }
	  else
	  {
		warn("In ftp: remote file $rfile not found.\n");
	  }
	  $badsize = 0;
	}
  }
}

sub ftp_fsize($$)
{
  # Return file size and "file exists" flag

  my ($ftp, $file) = @_;
  my (@swords);
  my $file_exists = 0;
  my $fsize = 0;

  @swords = $ftp->dir($file);
  
  if (not ($swords[0] =~ m/No such file or directory/))
  {
      my (@sline) = split ' ', $swords[0];
	  $fsize = splice(@sline, 4, 1);
      $file_exists = 1;
  }
  ($fsize, $file_exists);
}

1;

__END__


=head1 NAME

Hv_checkout.pm - provide functions for reliable checkout from Harvest.

=head1 SYNOPSIS

use Hv_checkout.pm

=head1 DESCRIPTION

Hv_checkout.pm contains four functions that make it possible to reliably check out
files from Harvest and maintain Unix reference directories with a minimal amount
of new code for each UDP.  The functions are:

create_co_list_query (I<oracle dbh>, I<environment>, I<state>, I<contents>, I<packages>, I<repositories>)

create_co_list (I<status>, I<contents>, I<versions>, I<repositories>)

checkout (I<environment>, I<state>, I<base dir>, I<drop leading path>, I<quiet>,  I<force>, I<footprint>, I<contents>, I<hco params>)

ftp_files (I<basedir>, I<drop leading path>, I<quiet>, I<checkout>, I<remote host>, I<remote user>, I<remote pw>, I<remote base dir>, I<contents>, I<user function>)    

=head1 FUNCTIONS

create_co_list_query ($dbh, $environment, $state, *contents, \@packages, \@repositories)

This function populates the contents hash according to the following rules:

If there are any repositories specified, the hash will only be populated by 
items in the specified repositories, otherwise the hash will be populated by
items in all repositories for the environment. In either case, the function
will keep track of the status of the highest version of any item in view for 
the given environment and state.

If there are no packages specified, the hash is populated with all items in
view at the specified state.  This includes any items which where loaded into
a repository during initial load (i.e., the packageobjid = 0) and never
modified, because they are visible to all states, as well as any items with
versions that are in the view associated with the specified state.

If packages are specified, the hash is populated with all items modified by
these packages with versions in the specified state's view.  If packages are
in a state whose state order is less than the specified state's state order,
then any items which do not have a version in the specified state's view are
also included, but the version is 0 and the status is "D".  This is so we can
automatically delete a file if it was created by a package and the package
gets demoted.

=head1 create_co_list ($status, *contents, \@versions, \@repositories)

This function fills the %contents hash with the files listed in the array @$versions,
setting the status to the one passed in ("N" or "D"), and the version number to the 
number found after a semicolon at the end of the file name.  If the status of the file
is normal ("N") and no version is found at the end of the file name, the file is not
included in the %contents hash.  If anything is passed in the array @$repositories, 
the prefix of the file name is compared to the names of the repositories, and
if it is found, the file is included in the contents hash.

Example:

 @versions = 
 ("/ccsapps_4.1/scripts/toolbar.parm;1", 
  "/ccsapps_4.1/scripts/service.parm;2",
  "/ccsapps_4.1/src/toolbar.c;3");

 @repositories = ("ccsapps_4.1", "cbase_4.1");

 create_co_list("N", *contents, \@versions, \@repositories)
 would populate %contents with 

 $contents{"/ccsapps_4.1/scripts"} = 
  [ [1, "N", "toolbar.parm"],
    [2, "N", "service.parm"] ]

 $contents{"/ccsapps_4.1/src"} = [ [3, "N", "toolbar.c"] ]

This function would be used by a UDP when there are a list of
files or versions passed to the UDP, typically for remove item, delete
version, or checkin file.

=head1 checkout ($environment, $state, $base, $drop_leading_path, $quiet, $force, $footprint, %contents, \@hco_params)

This is the Harvest checkout function.  This function reliably checks out
files from Harvest, and will reissue the checkout request if necessary.  It 
is passed a contents hash that has been populated by create_co_list or 
create_co_list_query.

=head1 ftp_files ($base, $drop_leading_path, $quiet, $checkout, $remote_host, $remote_user, $remote_pw, $remote_base, *contents, $optional_function)

This function ftp's files contained in the contents hash to the remote host and
the remote base directory, verifying the size for each file transferred.  If the
status of the file is "D", the file is deleted from the remote host.  An optional
function name may be passed, which is called with the ftp handle, the remote base
directory, and the name of the file, for files with status "N".  This optional 
function may be used for such operations as changing the remote file permissions.

=head1 OPTIONS

=over 4

=item $base

Base directory.  Should be a full path name beginning with "/".

=item $checkout 

If true in ftp_files: only ftp files that have been checked out.

=item *contents

A typeglob of a hash that gets populated in the following way:

 $contents{"/ccsapps_4.1/scripts"} =
  [ [1, "N", "toolbar.parm"],
    [2, "N", "service.parm"] ]

 $contents{"/ccsapps_4.1/src"} = [ [3, "N", "toolbar.c"] ]

=item $drop_leading_path

A number greater than or equal to zero, that represents the number
of path elements that should be dropped from the beginning of the
path.  For example, a value of 2 would cause "/tmp/ccsapps_4.1/src"
to become "/src".

=item $environment

The Harvest environment (e.g. ccs_split)

=item $footprint

Boolean value to run hft to make Harvest footprint after checkout.

=item $force

If true, in checkout change all file permissions to read-only before
checking out files.

=item \@hco_params

Reference to array of parameters to pass to hco. 
(e.g., "-br" for browse mode, "-sy" for sync mode, CB<"-r"> for read only, etc.)

=item $dbh

Oracle database handle (e.g. pta001)

=item \@packages

A reference to a list of package names. In checkout: if null, all
items will be checked out, otherwise only the items changed by these
packages will be checked out.

=item $quiet

If true in ftp_files only issue warnings for ftp failures to stdout.
If true in checkout, do not write export logs to stdout.

=item $remote_host

Remote host to ftp files to.

=item $remote_pw

Password for remote user id.

=item $remote_user

Remote user id used for ftp log on.

=item \@repositories

A reference to a list of repository names.  In checkout: if null, 
all items will be checked out, otherwise only the items in these
repositories will be checked out.

=item $state

Harvest state, such as "Development" or "prod".

=item $status

Status of a file or set of files, set to "N" for normal, or 
"D" for delete.

=cut


