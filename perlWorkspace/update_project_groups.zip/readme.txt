NAME
    OCN_update_project_groups

SYNOPSIS
    OCN_update_project_groups [oldgroup] [newgroup] [environment]

DESCRIPTION
    OCN_update_project_groups will update the group access for all processes
    and access controls for the environment and state.

PARAMETERS
    oldgroup
        The original group. If "<%>" is passed, then all of the groups of
        the form <_Replace with Project_XXX> will be changed to
        [newgroup]_XXX.

    newgroup
        The new group.

    environment
        The environment to be displayed. (Required)

