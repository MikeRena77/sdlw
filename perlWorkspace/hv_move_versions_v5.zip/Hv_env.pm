package Hv_env;

%Hv_env::Update = ( PROD_INSTANCE => {user => "harvest", password => "prod"},
				   TEST_INSTANCE => {user => "harvest", password => "test"},
				 );

1;
