
hv_move_versions [environment] [user] [package] [version]


From the Workbench, invoke the "Move Versions" process (actually a checkout
process), specifying in the Versions field the versions you wish to move
(select them directly from the Workbench or use the version chooser) and
specify in the Package field the package you want to move the versions to.
The settings for client directory, filters, and options don't matter.  Execute
the process by hitting "Check Out".  The UDP runs, displays informational and
error messages, then exits with an intentional failure, causing the Checkout
Process to halt.  You'll see the results when you refresh the Workbench.
Unfortunately, it doesn't look like the Harvest Workbench displays any
messages from the prelink process, even if they're written to stdout.



How it works:

A Concurrent Update Checkout process is invoked, which has a Pre-Linked
server-side UDP.  The UDP runs the script, passing it the Environment name,
State name, Package name, and list of Versions.  The script queries the
database to validate various conditions, then updates the appropriate data in
the database.

CCC/Harvest Setup:

In CCC/Harvest, set up a Checkout process and enable the Update mode
(Concurrent Update or Reserve would work equally well, but NOT Browse or
Synchronize).  The default settings don't matter because this process isn't
even going to run.  Name this process something like "Move Versions to
Different Package" and set the access to it as you dare.  To this process,
pre-link a UDP process with the following program line:

hv_move_versions [environment] [user] ["package"] ["version"]

You probably need to change the path of the perl binary in the first line.
You'll also need to change the Hv_env.pm file.  Replace PROD_INSTANCE and
TEST_INSTANCE with your actual instance names, and the user harvest and
password with the actual values.


Credit goes to Tom Cameron, Computer Associates, for the ideas and description text.
Any programming errors are all mine, alas.